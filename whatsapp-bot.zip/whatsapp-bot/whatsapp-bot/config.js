// يجب عليك عدم تعديل اي شئ من بدايه السطر ال13 لعدم تخريب اللبوت #
// 𝑩𝒐𝒅𝒆 𝑪𝒐𝒓𝒍𝒆𝒐𝒏𝒆 𝑩𝑶𝑻-𝑴𝑫
import { watchFile, unwatchFile } from 'fs' 
import chalk from 'chalk'
import { fileURLToPath } from 'url'


global.owner = [
  ['967773463719', '⋰ᔕ卂ᗪ❀⋱', true],
  ['967773463719', 'سكران ببنزين', true],
]


global.mods = []
global.prems = []
global.APIKeys = {}

global.libreria = 'Baileys'
global.baileys = 'V 6.7.16' 
global.vs = '2.2.0'
global.nameqr = '𝑸𝑹'
global.namebot = 'بـــــ𝑘𝑖𝑟𝑜ـــــوت'
global.namedev = 'ᔕ卂ᗪ'
global.tg = 'https://t.me/whatsapp_botz'
global.sessions = 'bodesessions'
global.jadi = 'JadiBots' 
global.yukiJadibts = true

global.packname = 'بـــــ𝑘𝑖𝑟𝑜ـــــوت'
global.namebot = 'بـــــ𝑘𝑖𝑟𝑜ـــــوت'
global.author = 'ᔕ卂ᗪ'
global.moneda = 'Dolar'
global.canalreg = '120363198000393338@newsletter'

global.namecanal = '⌜ بـــــ𝑘𝑖𝑟𝑜ـــــوت 💀 ⌟  || كيرو بوت 💀'
global.canal = ''
global.idcanal = '120363198000393338@newsletter'

global.ch = {
ch1: '120363198000393338@newsletter',
}

global.multiplier = 69 
global.maxwarn = '2'


let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})