import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
    // تفاعل "القرار"
    await m.react('👁️‍🗨️')

    const ownerNumber = '967773463719'
    const ownerName = 'ᔕ卂ᗪ'
    const ownerImage = 'https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg'

    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${ownerName}\nTEL;type=CELL;type=VOICE;waid=${ownerNumber}:${ownerNumber}\nEND:VCARD`

    // خطاب القوة الصامتة (احترافي، غامض، ومرعب تقنياً)
    let txt = `*── ❪ 𝖲𝖸𝖲𝖳𝖤𝖬 𝖠𝖢𝖢𝖤𝖲𝖲: 𝖮𝖶𝖭𝖤𝖱 ❫ ──*\n\n`
    txt += `لقد تم فتح قناة اتصال مباشرة مع "المصدر". تم أرشفة بياناتك وتحديد موقعك الرقمي داخل النظام. 🌑🔗\n\n`
    txt += `• *بـروتوكول الـحـمـاية:* أي محاولة للعبث أو الإغراق (Spam) ستؤدي إلى تفعيل تلقائي لبروتوكول الـ (Kernel Crash) على حسابك. نحن لا نتفاوض، نحن نصفي الحسابات تقنياً. 🌀⚡\n\n`
    txt += `• *سـياسـة الـرد:* المطور لا يستقبل إلا الرسائل "ذات القيمة". ادخل في صلب طلبك فوراً. أي كلام خارج النطاق العملي سيتم تجاهله وحظر صاحبه صمتاً. 👤📑\n\n`
    txt += `• *الـتـحـذير الأخـير:* لا تحاول اختبار حدودنا، فخلف هذا الهدوء نظام صُمم ليحطم من يتجاوزه. 🛠️📡\n\n`
    txt += `━━━━━━━━━━━━━━━━━━━━\n\n`
    txt += `📟 *𝖣𝗂𝗋𝖾𝖼𝗍 𝖫𝗂𝗇𝗄:* wa.me/${ownerNumber}\n\n`
    txt += `*ـ نـحـن نرى مـن خـلـف الـشـاشـات.. فـاحـذر. ⚰️🦇*`

    // إرسال الكرت بتنسيق الـ Dark Web الاحترافي
    await conn.sendMessage(m.chat, {
        contacts: {
            displayName: ownerName,
            contacts: [{ vcard }]
        },
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝖴𝖭𝖪𝖭𝖮𝖶𝖭 𝖤𝖭𝖳𝖨𝖳𝖸: ${ownerName}`,
                body: `𝖣𝖺𝗍𝖺 𝖲𝗍𝗋𝖾𝖺𝗆: 𝖤𝗇𝖼𝗋𝗒𝗉𝗍𝖾𝖽 | 𝖫𝗈𝗀𝗀𝗂𝗇𝗀 𝖮𝗇`,
                thumbnailUrl: ownerImage,
                sourceUrl: `https://wa.me/${ownerNumber}`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })

    // إرسال النص "المرعب" ببرود
    await conn.sendMessage(m.chat, { 
        text: txt,
        mentions: [m.sender] 
    }, { quoted: m })
}

handler.help = ['مطور']
handler.tags = ['main']
handler.command = /^(مطور|المطور|owner|developer)$/i 

export default handler
