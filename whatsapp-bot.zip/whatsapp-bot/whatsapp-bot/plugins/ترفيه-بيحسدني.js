let toM = a => '@' + a.split('@')[0]
function handler(m, { groupMetadata }) {
  let ps = groupMetadata.participants.map(v => v.id)
  let a = ps.getRandom()
  let b
  do b = ps.getRandom()
  while (b === a)
  m.reply(`▣──────────────────
│
*اكثر واحد يحدك هو ذا*
▣─❧ ${toM(a)} 
│
▣──────────────────`, null, {
    mentions: [a, b]
  })
}
handler.help = ['بيحسدني']
handler.tags = ['fun']
handler.command = ['بيحسدني']
handler.group = true
export default handler

Array.prototype.getRandom = function () {
  return this[Math.floor(Math.random() * this.length)]
}