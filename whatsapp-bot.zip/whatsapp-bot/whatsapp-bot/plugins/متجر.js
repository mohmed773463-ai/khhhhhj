import { prepareWAMessageMedia } from '@whiskeysockets/baileys'

// ===================== أقسام المتجر =====================
const shopSections = {
    'الرتب': {
        name: '👑 الرتب والألقاب',
        icon: '👑',
        items: [
            { id: 'vip_week', name: '⭐ VIP لمدة أسبوع', price: 5000, desc: '✨ رتبة VIP مميزة لمدة 7 أيام', effect: '• لقب VIP 🔥 يظهر بجانب اسمك\n• خصم 10% على جميع المشتريات\n• تحية خاصة من البوت كل صباح\n• رمز مميز في بروفايلك' },
            { id: 'vip_month', name: '⭐ VIP لمدة شهر', price: 15000, desc: '✨ رتبة VIP لمدة 30 يوم', effect: '• لقب VIP 🔥 يظهر بجانب اسمك\n• خصم 15% على جميع المشتريات\n• تحية خاصة + هدايا أسبوعية\n• رمز مميز + دخول غرف VIP\n• أولوية الرد من البوت' },
            { id: 'gold_month', name: '🏆 GOLD لمدة شهر', price: 30000, desc: '🏆 رتبة GOLD الذهبية', effect: '• لقب GOLD 👑 يظهر بجانب اسمك\n• خصم 25% على جميع المشتريات\n• جميع مميزات VIP مضاعفة\n• شارة ذهبية في بروفايلك\n• حماية خاصة من البوت' },
            { id: 'custom_title', name: '✨ لقب مخصص', price: 8000, desc: '📝 لقب من اختيارك', effect: '• تقدر تختار أي لقب تبي\n• اللقب يظهر بجانب اسمك في كل رسالة\n• اللقب يظهر في قائمة الأغنياء\n• يمكن تغييره مرة كل أسبوع' },
            { id: 'special_badge', name: '🏅 شارة مميزة', price: 10000, desc: '🏅 شارة نادرة', effect: '• شارة نادرة بجانب اسمك ✨\n• الشارة تظهر في بروفايلك\n• تحصل على احترام وتقدير\n• شارة حصرية للمتميزين' }
        ]
    },
    'الحماية': {
        name: '🛡️ الحماية',
        icon: '🛡️',
        items: [
            { id: 'anti_kick', name: '🛡️ درع الطرد', price: 7000, desc: '🚫 حماية من الطرد', effect: '• أي مشرف يحاول يطردك البوت يمنعه\n• الحماية تشتغل في أي مجموعة فيها البوت\n• تدوم لمدة 7 أيام' },
            { id: 'anti_mute', name: '🔇 درع الكتم', price: 5000, desc: '🔇 حماية من الكتم', effect: '• أي مشرف يحاول يكتمك البوت يمنعه\n• الحماية تشتغل في أي مجموعة\n• تدوم لمدة 7 أيام' },
            { id: 'anti_delete', name: '🗑️ حماية الحذف', price: 6000, desc: '🗑️ ما حد يحذف رسائلك', effect: '• أي مشرف يحاول يحذف رسائلك البوت يمنعه\n• رسائلك تبقى آمنة\n• تدوم لمدة 30 يوم' },
            { id: 'anti_spam', name: '🚫 حماية السبام', price: 4000, desc: '🚫 حماية من التقييد', effect: '• البوت ما يقدر يقيدك لو أرسلت كتير\n• حماية من السبام\n• تدوم لمدة 3 أيام' }
        ]
    },
    'المميزات': {
        name: '⚡ مميزات خاصة',
        icon: '⚡',
        items: [
            { id: 'custom_cmd', name: '⚙️ أمر مخصص', price: 12000, desc: '💬 أمر باسمك', effect: '• تقدر تعمل أمر باسمك زي .سلمان\n• البوت يرد بأي رد تحدده\n• الأمر يدوم للأبد' },
            { id: 'welcome_msg', name: '👋 رسالة ترحيب', price: 8000, desc: '🎉 ترحيب باسمك', effect: '• البوت يرحب بالأعضاء الجدد باسمك\n• الرسالة تظهر صورتك واسمك\n• تدوم 30 يوم' },
            { id: 'auto_react', name: '😍 تفاعل تلقائي', price: 9000, desc: '❤️ تفاعلات على رسائلك', effect: '• البوت يتفاعل مع رسائلك بإيموجيات\n• تقدر تختار الإيموجي اللي تبي\n• تدوم 30 يوم' },
            { id: 'auto_reply', name: '💬 رد تلقائي', price: 11000, desc: '🤖 ردود مخصصة', effect: '• البوت يرد برد انت كاتبه\n• تقدر تحدد كلمة وردها\n• تدوم للأبد' }
        ]
    },
    'التطوير': {
        name: '📈 تطوير الحساب',
        icon: '📈',
        items: [
            { id: 'exp_boost', name: '📚 مضاعف النقاط', price: 8000, desc: '⚡ نقاطك تتضاعف', effect: '• كل النقاط اللي تجيبها تتضاعف\n• مضاعفة ×2\n• تدوم 3 أيام' },
            { id: 'money_boost', name: '💰 مضاعف الفلوس', price: 10000, desc: '💰 فلوسك تتضاعف', effect: '• كل الفلوس اللي تكسبها تتضاعف\n• مضاعفة ×2\n• تدوم 3 أيام' },
            { id: 'bank_interest', name: '🏦 فائدة بنكية', price: 12000, desc: '📈 فائدة يومية', effect: '• تحصل على 5% فائدة يومية\n• الفائدة تضاف لرصيد بنكك\n• تدوم 30 يوم' },
            { id: 'daily_double', name: '🎁 مضاعف اليومي', price: 5000, desc: '🎁 مكافأة اليومي تتضاعف', effect: '• مكافأة اليومي تتضاعف ×2\n• تدوم ليوم واحد' }
        ]
    },
    'الترفيه': {
        name: '🎮 ترفيه وألعاب',
        icon: '🎮',
        items: [
            { id: 'gift_box', name: '🎁 صندوق فاخر', price: 10000, desc: '🎁 صندوق بجوائز', effect: '• تحصل على مبلغ عشوائي\n• بين 5000 - 25000$\n• جائزة فورية' },
            { id: 'love_letter', name: '💌 رسالة حب', price: 2000, desc: '💕 رسالة رومانسية', effect: '• تقدر ترسل رسالة حب لأي شخص\n• البوت يوصلها باسمك\n• 5 استخدامات' },
            { id: 'roast_card', name: '🔥 تهزيء', price: 1500, desc: '😝 تهزيء مضحك', effect: '• تقدر تتهزأ على أي شخص\n• تهزيء ذكي ومضحك\n• 5 استخدامات' },
            { id: 'hug_card', name: '🤗 حضن', price: 1000, desc: '🤗 حضن دافئ', effect: '• تقدر تحتضن أي شخص\n• رسالة حلوة ودافئة\n• 5 استخدامات' }
        ]
    }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    let user = global.db.data.users[m.sender]
    
    // التأكد من وجود البيانات
    if (typeof user.money === 'undefined') user.money = 0
    if (typeof user.bank === 'undefined') user.bank = 0
    if (!user.inventory) user.inventory = {}
    if (!user.temp) user.temp = {}
    if (!user.effects) user.effects = {}

    // ===================== عرض المتجر =====================
    if (command === "متجر") {
        let buttons = Object.keys(shopSections).map(section => ({
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: `${shopSections[section].icon} ${shopSections[section].name}`,
                id: `${usedPrefix}قسم ${section}`
            })
        }))

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "🏬 متجر كيرو" },
                        body: { 
                            text: `╭━━━━━━━━━━━━━━━╮\n┃ ✨ مرحباً *${m.pushName}* ✨\n┃\n┃ 💰 فلوسك: ${user.money}$\n┃ 🏦 بنكك: ${user.bank}$\n┃\n┃ 📦 *اختر القسم:*\n┃\n${Object.keys(shopSections).map((s, i) => `┃ ${i+1}. ${shopSections[s].icon} ${shopSections[s].name}`).join('\n')}\n┃\n╰━━━━━━━━━━━━━━━╯` 
                        },
                        footer: { text: "اضغط على القسم اللي تبي تشتري منه 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {})
    }

    // ===================== عرض القسم =====================
    if (command === "قسم") {
        let sectionKey = args[0]
        let section = shopSections[sectionKey]
        
        if (!section) {
            return m.reply(`⚠️ القسم غير موجود!\n\nالأقسام المتاحة:\n${Object.keys(shopSections).map(k => `${shopSections[k].icon} ${shopSections[k].name}`).join('\n')}`)
        }

        let buttons = section.items.map((item, idx) => ({
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: `${item.name} - ${item.price}$`,
                id: `${usedPrefix}شراء ${sectionKey} ${idx}`
            })
        }))

        buttons.push({
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🔙 رجوع للقائمة",
                id: `${usedPrefix}متجر`
            })
        })

        let itemsList = section.items.map((item, i) => 
            `┃ ${i+1}. *${item.name}*\n┃    💰 ${item.price}$\n┃    📝 ${item.desc}`
        ).join('\n┃\n')

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: `${section.icon} ${section.name}` },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n${itemsList}\n┃\n┃ 💰 رصيدك: ${user.money}$\n╰━━━━━━━━━━━━━━━╯\n\n*اختر السلعة 👇*` },
                        footer: { text: "اضغط على السلعة للشراء" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {})
    }

    // ===================== شراء =====================
    if (command === "شراء") {
        let sectionKey = args[0]
        let itemIndex = parseInt(args[1])
        
        let section = shopSections[sectionKey]
        if (!section) return m.reply('⚠️ القسم غير موجود!')
        
        let item = section.items[itemIndex]
        if (!item) return m.reply('⚠️ السلعة غير موجودة!')
        
        if (user.money < item.price) {
            return m.reply(`❌ فلوسك ما تكفي!\n💰 السعر: ${item.price}$\n💵 اللي معاك: ${user.money}$`)
        }
        
        // تخزين مؤقت لعملية الشراء
        user.temp.buyItem = {
            section: sectionKey,
            itemIndex: itemIndex,
            price: item.price,
            itemName: item.name,
            itemId: item.id,
            itemDesc: item.desc,
            itemEffect: item.effect
        }
        
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 دفع كاش", id: `${usedPrefix}دفع كاش` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏦 دفع بنك", id: `${usedPrefix}دفع بنك` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❌ إلغاء", id: `${usedPrefix}دفع الغاء` }) }
        ]
        
        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "💳 تأكيد الشراء" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ 🛍️ *${item.name}*\n┃\n┃ 💰 السعر: ${item.price}$\n┃\n┃ 📝 *الوصف:*\n┃ ${item.desc}\n┃\n┃ ✨ *التأثير:*\n${item.effect.split('\n').map(line => `┃ ${line}`).join('\n')}\n┃\n╰━━━━━━━━━━━━━━━╯\n\n*اختر طريقة الدفع 👇*` },
                        footer: { text: "اختر الطريقة المناسبة" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {})
    }

    // ===================== دفع =====================
    if (command === "دفع") {
        let method = args[0]
        
        if (method === 'الغاء') {
            delete user.temp.buyItem
            return m.reply('❌ تم إلغاء الشراء.')
        }
        
        if (!user.temp.buyItem) {
            return m.reply('⚠️ مافيه عملية شراء!\nاستخدم .متجر عشان تشتري.')
        }
        
        let buyData = user.temp.buyItem
        let section = shopSections[buyData.section]
        let item = section.items[buyData.itemIndex]
        
        if (method === 'كاش') {
            if (user.money < buyData.price) {
                delete user.temp.buyItem
                return m.reply(`❌ فلوسك ما تكفي!\n💰 السعر: ${buyData.price}$\n💵 اللي معاك: ${user.money}$`)
            }
            user.money -= buyData.price
        } 
        else if (method === 'بنك') {
            if (user.bank < buyData.price) {
                delete user.temp.buyItem
                return m.reply(`❌ رصيد البنك ما يكفي!\n💰 السعر: ${buyData.price}$\n🏦 رصيد البنك: ${user.bank}$`)
            }
            user.bank -= buyData.price
        }
        else {
            return m.reply('⚠️ استخدم: دفع كاش أو دفع بنك')
        }
        
        // تخزين السلعة في المخزون
        if (!user.inventory[buyData.itemId]) {
            user.inventory[buyData.itemId] = 0
        }
        user.inventory[buyData.itemId]++
        
        // تطبيق تأثيرات السلعة
        let effectResult = ''
        let expiryDate = Date.now()
        
        switch (buyData.itemId) {
            case 'vip_week':
                user.effects.vip = { active: true, expiry: Date.now() + (7 * 24 * 60 * 60 * 1000), type: 'week' }
                effectResult = '✅ تم تفعيل رتبة VIP لمدة أسبوع'
                break
            case 'vip_month':
                user.effects.vip = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000), type: 'month' }
                effectResult = '✅ تم تفعيل رتبة VIP لمدة شهر'
                break
            case 'gold_month':
                user.effects.gold = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل رتبة GOLD لمدة شهر'
                break
            case 'custom_title':
                user.temp.waitingForTitle = true
                effectResult = '✅ أرسل اللقب اللي تبي يظهر بجانب اسمك (ماكس 15 حرف)'
                break
            case 'special_badge':
                user.effects.badge = { active: true }
                effectResult = '✅ تم تفعيل الشارة المميزة'
                break
            case 'name_color':
                user.effects.nameColor = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ اسمك هيظهر باللون الذهبي لمدة 30 يوم'
                break
            case 'anti_kick':
                user.effects.antiKick = { active: true, expiry: Date.now() + (7 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل درع الطرد لمدة 7 أيام'
                break
            case 'anti_mute':
                user.effects.antiMute = { active: true, expiry: Date.now() + (7 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل درع الكتم لمدة 7 أيام'
                break
            case 'anti_delete':
                user.effects.antiDelete = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل حماية الحذف لمدة 30 يوم'
                break
            case 'anti_spam':
                user.effects.antiSpam = { active: true, expiry: Date.now() + (3 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل حماية السبام لمدة 3 أيام'
                break
            case 'custom_cmd':
                user.effects.customCmd = { active: true }
                effectResult = '✅ أرسل اسم الأمر والرد المطلوب (مثال: سلمان | مرحباً سلمان)'
                break
            case 'welcome_msg':
                user.effects.welcomeMsg = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل رسالة الترحيب باسمك لمدة 30 يوم'
                break
            case 'auto_react':
                user.effects.autoReact = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000) }
                effectResult = '✅ تم تفعيل التفاعل التلقائي لمدة 30 يوم'
                break
            case 'auto_reply':
                user.effects.autoReply = { active: true }
                effectResult = '✅ أرسل الكلمة والرد المطلوب (مثال: سلام | وعليكم السلام)'
                break
            case 'exp_boost':
                user.effects.expBoost = { active: true, expiry: Date.now() + (3 * 24 * 60 * 60 * 1000), multiplier: 2 }
                effectResult = '✅ تم تفعيل مضاعف النقاط لمدة 3 أيام'
                break
            case 'money_boost':
                user.effects.moneyBoost = { active: true, expiry: Date.now() + (3 * 24 * 60 * 60 * 1000), multiplier: 2 }
                effectResult = '✅ تم تفعيل مضاعف الفلوس لمدة 3 أيام'
                break
            case 'bank_interest':
                user.effects.bankInterest = { active: true, expiry: Date.now() + (30 * 24 * 60 * 60 * 1000), rate: 5 }
                effectResult = '✅ تم تفعيل الفائدة البنكية 5% لمدة 30 يوم'
                break
            case 'daily_double':
                user.effects.dailyDouble = { active: true, expiry: Date.now() + (24 * 60 * 60 * 1000) }
                effectResult = '✅ مكافأة اليومي مضاعفة لمدة 24 ساعة'
                break
            case 'gift_box':
                let reward = Math.floor(Math.random() * 20000) + 5000
                user.money += reward
                delete user.temp.buyItem
                return m.reply(`╭━━━━━━━━━━━━━━━╮\n┃ 🎁 *${item.name}*\n┃\n┃ ✨ فتحت الصندوق وحصلت على:\n┃ 💰 ${reward}$\n┃\n┃ 💵 رصيدك الحالي: ${user.money}$\n╰━━━━━━━━━━━━━━━╯`)
            case 'love_letter':
                user.effects.loveLetter = { active: true, uses: 5 }
                effectResult = '✅ عندك 5 رسائل حب جاهزة\nاستخدم .حب @الشخص عشان ترسل'
                break
            case 'roast_card':
                user.effects.roastCard = { active: true, uses: 5 }
                effectResult = '✅ عندك 5 تهزيئات جاهزة\nاستخدم .تهزيء @الشخص عشان تتهزأ'
                break
            case 'hug_card':
                user.effects.hugCard = { active: true, uses: 5 }
                effectResult = '✅ عندك 5 أحضان جاهزة\nاستخدم .حضن @الشخص عشان تحتضن'
                break
        }
        
        let methodName = method === 'كاش' ? 'المحفظة' : 'البنك'
        let remaining = method === 'كاش' ? user.money : user.bank
        
        let response = `╭━━━━━━━━━━━━━━━╮\n┃ ✅ *تم الشراء بنجاح!*\n┃\n┃ 🛍️ ${item.name}\n┃ 💰 ${item.price}$\n┃ 💳 من: ${methodName}\n┃ 📉 المتبقي: ${remaining}$\n┃\n┃ ✨ *التأثير:*\n${item.effect.split('\n').map(line => `┃ ${line}`).join('\n')}\n┃\n┃ ${effectResult}\n╰━━━━━━━━━━━━━━━╯`
        
        delete user.temp.buyItem
        
        return m.reply(response)
    }
}

handler.help = ["متجر"]
handler.tags = ["economy"]
handler.command = /^(متجر|shop|قسم|شراء|دفع)$/i

export default handler