import axios from 'axios'

async function ttSearch(query) {
    return new Promise(async (resolve, reject) => {
        axios("https://tikwm.com/api/feed/search", {
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "cookie": "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
            },
            data: {
                "keywords": query,
                "count": 12,
                "cursor": 0,
                "web": 1,
                "hd": 1
            },
            method: "POST"
        }).then(res => {
            resolve(res.data.data)
        }).catch(err => {
            reject(err)
        })
    })
}

let sentVideos = []

let handler = async (m, { conn }) => {
    try {
        let data = await ttSearch('ايديت-انمي')
        let videos = data.videos

        // ترتيب الفيديوهات حسب الأحدث
        videos.sort((v1, v2) => new Date(v2.created_at) - new Date(v1.created_at))

        // العثور على فيديو جديد لم يتم إرساله من قبل
        let newVideo = videos.find(v => !sentVideos.includes(v.id))

        if (!newVideo) {
            return m.reply('💀 لا توجد فيديوهات جديدة حالياً، يرجى المحاولة لاحقاً.')
        }

        let videoUrl = 'https://tikwm.com/' + newVideo.play

        // إرسال الفيديو مباشرة بدون أي زر أو روابط
        await conn.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: 'ايديات-انمي\nبـــــ𝑘𝑖𝑟𝑜ـــــوت💀'
        }, { quoted: m })

        sentVideos.push(newVideo.id)
    } catch (err) {
        console.error(err)
        m.reply('💀 حدث خطأ أثناء جلب الفيديو')
    }
}

handler.help = ['ايديت-انمي']
handler.tags = ['random']
handler.command = /^(ايديت-انمي)$/i
handler.limit = true
handler.register = true

export default handler