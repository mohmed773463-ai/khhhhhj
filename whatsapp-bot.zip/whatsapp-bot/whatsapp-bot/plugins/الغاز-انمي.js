+import fs from 'fs';

const timeout = 60000; // دقيقة واحدة
const poin = 500;

const handler = async (m, { conn, command }) => {
    conn.tekateki = conn.tekateki ? conn.tekateki : {};
    const id = m.chat;

    // 1. التحقق إذا كان هناك لغز شغال حالياً
    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*❐┃ في سؤال شغال يــا بــاكا.. جاوب عليه أول! ❌ ❯*', conn.tekateki[id][0]);
    }

    // 2. تحديد مسار الملف (تأكد أن الملف موجود في هذا المسار بالضبط)
    const filePath = './src/game/الغاز-انمي.json';

    // التحقق من وجود الملف قبل القراءة لتجنب توقف البوت
    if (!fs.existsSync(filePath)) {
        return m.reply(`⚠️ خطأ: ملف الألغاز غير موجود في المسار:\n${filePath}`);
    }

    // 3. قراءة البيانات واختيار لغز عشوائي
    const tekateki = JSON.parse(fs.readFileSync(filePath));
    const json = tekateki[Math.floor(Math.random() * tekateki.length)];

    // 4. تنسيق الرسالة الفخمة
    const caption = `
   *『 ⚡ لُـغْـز الأنِـمِـي ⚡ 』*
   
> *الـسـؤال:* ⌈ ${json.question} ⌋ 

╮───────────────────⟢ـ
┆ *⏳ الـوقـت:* ${(timeout / 1000).toFixed(0)} ثانية
┆ *💰 الـجـائـزة:* ${poin} دولار
┆ *🤖 الـمـطـور:* كـيـرو الـعـالـمـي ⚡
╯───────────────────⟢ـ

*⚠️ أجب بسرعة قبل انتهاء الوقت!*
`.trim();

    // 5. حفظ اللغز وتوقيت الحذف
    conn.tekateki[id] = [
        await conn.reply(m.chat, caption, m),
        json,
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*❮ ⌛┇انتهى الوقت┇⌛❯*\n\n*❐↞┇الاجـابـة✅↞* 『 ${json.response} 』`, conn.tekateki[id][0]);
                delete conn.tekateki[id];
            }
        }, timeout)
    ];
};

handler.help = ['لغز-انمي'];
handler.tags = ['game'];
handler.command = /^(لغز-انمي|لغز_انمي|الغاز-انمي|الغاز_انمي)$/i;

export default handler;
import fs from 'fs';

const timeout = 60000; // دقيقة واحدة
const poin = 500;

const handler = async (m, { conn, command }) => {
    conn.tekateki = conn.tekateki ? conn.tekateki : {};
    const id = m.chat;

    // 1. التحقق إذا كان هناك لغز شغال حالياً
    if (id in conn.tekateki) {
        return conn.reply(m.chat, '*❐┃ في سؤال شغال يــا بــاكا.. جاوب عليه أول! ❌ ❯*', conn.tekateki[id][0]);
    }

    // 2. تحديد مسار الملف (تأكد أن الملف موجود في هذا المسار بالضبط)
    const filePath = './src/game/الغاز-انمي.json';

    // التحقق من وجود الملف قبل القراءة لتجنب توقف البوت
    if (!fs.existsSync(filePath)) {
        return m.reply(`⚠️ خطأ: ملف الألغاز غير موجود في المسار:\n${filePath}`);
    }

    // 3. قراءة البيانات واختيار لغز عشوائي
    const tekateki = JSON.parse(fs.readFileSync(filePath));
    const json = tekateki[Math.floor(Math.random() * tekateki.length)];

    // 4. تنسيق الرسالة الفخمة
    const caption = `
   *『 ⚡ لُـغْـز الأنِـمِـي ⚡ 』*
   
> *الـسـؤال:* ⌈ ${json.question} ⌋ 

╮───────────────────⟢ـ
┆ *⏳ الـوقـت:* ${(timeout / 1000).toFixed(0)} ثانية
┆ *💰 الـجـائـزة:* ${poin} دولار
┆ *🤖 الـمـطـور:* كـيـرو الـعـالـمـي ⚡
╯───────────────────⟢ـ

*⚠️ أجب بسرعة قبل انتهاء الوقت!*
`.trim();

    // 5. حفظ اللغز وتوقيت الحذف
    conn.tekateki[id] = [
        await conn.reply(m.chat, caption, m),
        json,
        poin,
        setTimeout(async () => {
            if (conn.tekateki[id]) {
                await conn.reply(m.chat, `*❮ ⌛┇انتهى الوقت┇⌛❯*\n\n*❐↞┇الاجـابـة✅↞* 『 ${json.response} 』`, conn.tekateki[id][0]);
                delete conn.tekateki[id];
            }
        }, timeout)
    ];
};

handler.help = ['لغز-انمي'];
handler.tags = ['game'];
handler.command = /^(لغز-انمي|لغز_انمي|الغاز-انمي|الغاز_انمي)$/i;

export default handler;
