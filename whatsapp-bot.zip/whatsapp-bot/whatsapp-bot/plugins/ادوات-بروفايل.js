import { xpRange } from '../lib/levelling.js'
import { createHash } from 'crypto'
import PhoneNumber from 'awesome-phonenumber'
import fetch from 'node-fetch'
import axios from 'axios'

function isPremium(userId) {
  return global.prems.includes(userId.split`@`[0])
}

let handler = async (m, { conn }) => {

  if (!m.isGroup) return

  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : m.fromMe
    ? conn.user.jid
    : m.sender

  if (!global.db.data.users[who]) {
    global.db.data.users[who] = {
      exp: 0,
      limit: 10,
      level: 0,
      role: 'مبتدئ',
      registered: false,
      age: 0,
      name: await conn.getName(who)
    }
  }

  let user = global.db.data.users[who]

  let pp = await conn.profilePictureUrl(who, 'image').catch(_ =>
    'https://i.ibb.co/0nMY9Y0/file.jpg'
  )

  let bio = await conn.fetchStatus(who).catch(_ => ({ status: '-' }))

  let { exp, limit, level, role, name, registered, age } = user

  let { min, xp, max } = xpRange(level, global.multiplier)

  let prem = isPremium(who)

  let sn = createHash('md5').update(who).digest('hex')

  let userNationality = 'غير معروف'

  try {
    let api = await axios.get(
      `https://delirius-apiofc.vercel.app/tools/country?text=${PhoneNumber(
        '+' + who.replace('@s.whatsapp.net', '')
      ).getNumber('international')}`
    )
    if (api.data?.result)
      userNationality = `${api.data.result.name} ${api.data.result.emoji}`
  } catch {}

  let img = await (await fetch(pp)).buffer()

  let userLevel = level
  let userExp = exp

  let { min: minExp, xp: xpMax } = xpRange(userLevel, global.multiplier)

  let xpToLevelUp = xpMax - userExp

  let d = new Date(Date.now() + 3600000)

  let locale = 'ar'

  let week = d.toLocaleDateString(locale, { weekday: 'long' })

  let date = d.toLocaleDateString(locale, {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })

  let dateIslamic = Intl.DateTimeFormat(
    locale + '-TN-u-ca-islamic',
    { day: 'numeric', month: 'long', year: 'numeric' }
  ).format(d)

  let time = d.toLocaleTimeString(locale, {
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric'
  })

  let uptime = clockString(process.uptime() * 1000)

  let totalreg = Object.keys(global.db.data.users).length

  let rtotalreg = Object.values(global.db.data.users).filter(
    user => user.registered == true
  ).length

  let txt = `『 بروفايل المستخدم 』

◦ الاسم : ${name}
◦ العمر : ${registered ? age + ' سنة' : '×'}
◦ الرقم : ${PhoneNumber(
    '+' + who.replace('@s.whatsapp.net', '')
  ).getNumber('international')}
◦ الجنسية : ${userNationality}
◦ الرابط : wa.me/${who.split`@`[0]}
◦ المستوى : ${userLevel}
◦ XP الإجمالي : ${userExp}
◦ XP للترقية : ${xpToLevelUp}
◦ بريميوم : ${prem ? 'نعم' : 'لا'}
◦ مسجل : ${registered ? 'نعم' : 'لا'}
◦ الحد اليومي : ${limit}

📅 اليوم : ${week}
📆 التاريخ : ${date}
🕌 التاريخ الإسلامي : ${dateIslamic}
⏰ الوقت : ${time}

🤖 تشغيل البوت : ${uptime}

👥 المستخدمين : ${rtotalreg} / ${totalreg}

🏅 الرتبة : ${role}`

  await conn.sendMessage(
    m.chat,
    {
      image: img,
      caption: txt,
      footer: 'بـــــ𝑘𝑖𝑟𝑜ـــــوت 💀'
    },
    { quoted: m }
  )
}

handler.help = [
  'بروفايل',
  'برفايلي',
  'perfil',
  'profile',
  'برفايل',
  'برافايل'
]

handler.tags = ['start']

handler.command =
  /^(بروفايل|برفايلي|perfil|profile|برفايل|برافايل)$/i

handler.register = true

export default handler


function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}