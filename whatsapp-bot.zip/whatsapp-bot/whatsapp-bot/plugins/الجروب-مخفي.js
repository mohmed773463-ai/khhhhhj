const handler = async (m, { conn, text, participants, isOwner, isROwner }) => {
    const allowed = ['967773463719', '967784808742', '196211688661063', '195193932370046']
    const isAllowed = allowed.some(id => m.sender.includes(id)) || isOwner || isROwner

    if (!isAllowed) {
        return conn.reply(m.chat, '「🔒」هذا الأمر خاص بالمطور فقط.', m)
    }

    const content = text ? text : '✨ انتباه يا شباب!'
    const users = participants.map(u => conn.decodeJid(u.id))

    // 8 مراحل تحميل
    const steps = [
        '⬛⬛⬛⬛⬛⬛⬛⬛  0%',
        '🟥⬛⬛⬛⬛⬛⬛⬛  12%',
        '🟥🟧⬛⬛⬛⬛⬛⬛  25%',
        '🟥🟧🟨⬛⬛⬛⬛⬛  37%',
        '🟥🟧🟨🟩⬛⬛⬛⬛  50%',
        '🟥🟧🟨🟩🟩⬛⬛⬛  62%',
        '🟥🟧🟨🟩🟩🟦⬛⬛  75%',
        '🟥🟧🟨🟩🟩🟦🟪⬛  87%',
    ]

    // الكلمات العربية — كل كلمة تنزل بعد الأخرى
    const words = [
        '💀 *ارتجفوا*',
        '⚡ *واخشوا*',
        '🔱 *فالموت*',
        '🌚🙂 *ياميتين*',
    ]

    // إرسال رسالة البداية والحصول على key
    const { key } = await conn.sendMessage(
        m.chat,
        { text: '📡 *جاري تشغيل نظام الإشارة المخفية...*', mentions: users },
        { quoted: m }
    )

    // مراحل شريط التقدم - بتأخير ثانية واحدة
    for (let i = 0; i < steps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 1000))
        await conn.sendMessage(
            m.chat,
            { text: `📡 *جاري إرسال الإشارة المخفية...*\n\n${steps[i]}`, edit: key, mentions: users }
        )
    }

    // الكلمات تنزل كلمة كلمة — كل واحدة تعدّل على نفس الرسالة
    let builtText = `${content}\n\n`
    for (let i = 0; i < words.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 1500))
        builtText += words[i] + '\n'
        await conn.sendMessage(
            m.chat,
            { text: builtText, edit: key, mentions: users }
        )
    }

    await m.react('✅')
}

handler.help = ['مخفي']
handler.tags = ['owner']
handler.command = /^(مخفي|hidetag|منشن_مخفي)$/i
handler.group = true

export default handler
