// auto-react.js
// ملف التفاعل التلقائي - يمكن تشغيله أو إطفائه

let handler = async (m, { conn, isAdmin, isBotAdmin, isOwner, isROwner }) => {
  // قائمة الإيموجيات العشوائية (أكثر من 50 إيموجي متنوع)
  const emojis = [
    '😂', '❤️', '👍', '🔥', '🥺', '😭', '😍', '✨', '💀', '😈',
    '👀', '🤔', '😴', '🤝', '🙏', '🫂', '💔', '🍃', '🌚', '💅',
    '🤡', '👻', '🎃', '🖤', '🤍', '💛', '💚', '💙', '💜', '🧡',
    '🩵', '🩷', '🩶', '🤎', '❤️‍🔥', '💞', '💕', '💓', '💗', '💖',
    '💘', '💝', '🫶', '👋', '🤲', '🙌', '👏', '🤝', '✌️', '🤟',
    '👊', '✊', '🤛', '🤜', '🤚', '🖐️', '✋', '🫸', '🫷', '👌',
    '🤌', '🤏', '🫳', '🫴', '👉', '👈', '👆', '👇', '👍🏼', '👎🏼',
    '🤲🏼', '🙏🏼', '💪', '🦵', '😆❤️', '👂', '👃', '🧠', '🫀', '🫁',
    '👁️', '👄', '🦷', '👅', '💋', '💘', '💌', '💎', '🔮', '🎁'
  ];
  
  // إيموجي عشوائي من القائمة
  const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
  
  // التحقق من حالة التفاعل التلقائي من قاعدة البيانات
  let isAutoReactEnabled = false;
  
  try {
    // محاولة جلب الإعدادات من قاعدة البيانات
    if (global.db && global.db.data && global.db.data.settings) {
      isAutoReactEnabled = global.db.data.settings.autoReact || false;
    } else {
      // إذا لم توجد قاعدة بيانات، نستخدم متغير عام مؤقت
      if (!global.autoReactSettings) global.autoReactSettings = { enabled: false };
      isAutoReactEnabled = global.autoReactSettings.enabled;
    }
    
    // إذا كان التفاعل التلقائي مفعلاً، نقوم بالتفاعل
    if (isAutoReactEnabled) {
      // نتأكد أننا لا نتفاعل مع رسائل البوت نفسه
      if (!m.key.fromMe && !m.isBaileys) {
        await m.react(randomEmoji);
        console.log(`✅ Auto-react: تم التفاعل على رسالة ${m.sender} بإيموجي ${randomEmoji}`);
      }
    }
  } catch (e) {
    console.error('❌ خطأ في التفاعل التلقائي:', e);
  }
};

// تعطيل تنفيذ الأمر العادي - هذا الملف للمراقبة فقط
handler.disabled = true; // هذا يمنع استدعاء handler كأمر

export default handler;