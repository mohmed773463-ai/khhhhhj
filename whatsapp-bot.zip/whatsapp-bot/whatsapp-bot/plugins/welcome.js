let handler = async (m, { conn, text, command, isAdmin, isOwner }) => {

  global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
  let chat = global.db.data.chats[m.chat]

  if (!(isOwner || isAdmin))
    return m.reply('❌ هذا الأمر للمشرفين والمطور فقط')

  if (chat.welcome === undefined) chat.welcome = true
  if (chat.farewell === undefined) chat.farewell = true
  if (!chat.welcomeText) chat.welcomeText = 'يسعدنا وجودك معنا! 🌟'
  if (!chat.farewellText) chat.farewellText = 'نتمنى له التوفيق 🙏'

  // ===== إعدادات الترحيب =====
  if (command === 'اعدادات-الترحيب') {
    let wStatus = chat.welcome ? '🟢 مفعل' : '🔴 متوقف'
    let fStatus = chat.farewell ? '🟢 مفعل' : '🔴 متوقف'
    return m.reply(`⚙️ *إعدادات الترحيب والوداع*\n\nالترحيب: ${wStatus}\nالوداع: ${fStatus}\n\nنص الترحيب:\n${chat.welcomeText}\n\nنص الوداع:\n${chat.farewellText}\n\n*الأوامر:*\n.تشغيل-الترحيب\n.ايقاف-الترحيب\n.تشغيل-الوداع\n.ايقاف-الوداع\n.تعيين-ترحيب النص\n.تعيين-وداع النص`)
  }

  if (command === 'تشغيل-الترحيب') {
    chat.welcome = true
    return m.reply('✅ تم تشغيل الترحيب التلقائي')
  }

  if (command === 'ايقاف-الترحيب') {
    chat.welcome = false
    return m.reply('❌ تم إيقاف الترحيب التلقائي')
  }

  if (command === 'تشغيل-الوداع') {
    chat.farewell = true
    return m.reply('✅ تم تشغيل الوداع التلقائي')
  }

  if (command === 'ايقاف-الوداع') {
    chat.farewell = false
    return m.reply('❌ تم إيقاف الوداع التلقائي')
  }

  if (command === 'تعيين-ترحيب') {
    if (!text) return m.reply('⚠️ اكتب النص بعد الأمر')
    chat.welcomeText = text
    return m.reply('✅ تم تغيير رسالة الترحيب')
  }

  if (command === 'تعيين-وداع') {
    if (!text) return m.reply('⚠️ اكتب النص بعد الأمر')
    chat.farewellText = text
    return m.reply('✅ تم تغيير رسالة الوداع')
  }
}

handler.command = [
  'تشغيل-الترحيب',
  'ايقاف-الترحيب',
  'تشغيل-الوداع',
  'ايقاف-الوداع',
  'تعيين-ترحيب',
  'تعيين-وداع',
  'اعدادات-الترحيب',
]

handler.group = true
handler.tags = ['group']
handler.help = ['تشغيل-الترحيب', 'ايقاف-الترحيب', 'تشغيل-الوداع', 'ايقاف-الوداع']

export default handler
