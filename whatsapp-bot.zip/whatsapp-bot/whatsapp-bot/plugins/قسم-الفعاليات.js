const handler = async (m, { conn }) => {

const imageUrl = "https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg";  

const messageText = `

『 مـرحـبـاً بــك يــا ⌊ ${m.pushName} ⌉ فـي 『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 』 』

⌝ قــســم الــفــعــالــيــات ┋🪄⌞ ⇊
⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔

📝┊⇇『 احـــزر 』
📍┊⇇『 عــلــم 』
🗃️┊⇇『 عــيــن 』
⚽┊⇇『 كـــورة 』
📿┊⇇『 ديــــن 』
✨┊⇇『 تــرتــيــب 』
🧩┊⇇『 تـفـكـيـك 』
❓┊⇇『 ســؤال 』
💡┊⇇『 إيـمـوجـي 』
🤔┊⇇『 لـغــــز 』
🍥┊⇇『 لـغــز-أنــمـي 』
🏅┊⇇『 ريــاضــة 』
🧠┊⇇『 ثـقـافـي 』

✦─━── •﹝💀﹞• ──━─✦
⟣ ✧ هـذا الـقـسـم قـيـد الـتـطـويـر ✧ ⟢
✦─━── •﹝💀﹞• ──━─✦

✦ 『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 』ــوت 💗💛
`.trim();

await conn.sendMessage(m.chat, { text: "*✦ جـــارٍ إرســال الـقـسـم....... 💗*" }, { quoted: m });  

await conn.sendMessage(m.chat, {  
    image: { url: imageUrl },  
    caption: messageText  
}, { quoted: m });  

await conn.sendMessage(m.chat, { react: { text: '💀', key: m.key } });

};

handler.command = /^قسم-الفعاليات$/i;
handler.tags = ["بــودي"];
handler.help = ["بــودي"];

export default handler;