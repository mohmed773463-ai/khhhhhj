let handler = async (m, { conn, args, command, isAdmin, isOwner }) => {

if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل في المجموعات فقط')

if (!(isAdmin || isOwner)) return m.reply('❌ هذا الأمر للمشرفين فقط')

global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}

let chat = global.db.data.chats[m.chat]

let type = args[0]

if (!type) {

let status = chat.welcome ? '✅ مفعل' : '❌ متوقف'

return m.reply(`

╭━━〔 نظام الترحيب 〕━━╮

تشغيل
.on welcome

ايقاف
.off welcome

الحالة الحالية
${status}

╰━━━━━━━━━━━━╯
`)
}

chat.welcome = command === 'on'

m.reply(`✅ تم ${chat.welcome ? 'تشغيل' : 'إيقاف'} الترحيب بنجاح`)

}

handler.command = ['on','off']
handler.group = true
handler.help = ['on welcome','off welcome']
handler.tags = ['group']

export default handler


/* ============================ */
/* الترحيب والوداع الحقيقي */
/* ============================ */

export async function participantsUpdate({ id, participants, action }, conn) {

global.db.data.chats = global.db.data.chats || {}

let chat = global.db.data.chats[id]

if (!chat) return
if (!chat.welcome) return

for (let user of participants) {

let name = await conn.getName(user)

if (action === 'add') {

let text = `
✨ ترحيب جديد ✨

اهلا بك
@${user.split('@')[0]}

نورت القروب ❤️

`

await conn.sendMessage(id,{
text,
mentions:[user]
})

}

if (action === 'remove') {

let text = `
💔 وداعاً

خرج العضو
@${user.split('@')[0]}

نتمنى له التوفيق

`

await conn.sendMessage(id,{
text,
mentions:[user]
})

}

}

}