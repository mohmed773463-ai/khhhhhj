const handler = async (m, { conn }) => {

    const imageUrl = "https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg";

    const messageText = `

*╔══✦〘💻〙✦══╗*
  『 مـرحـبــاً بـك يـا ⌊ ${m.pushName} ⌉ 』
        فــي قـســم الـبـرمجــة
      داخـل بـوت *『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 』*
*╚══✦〘💻〙✦══╝*

*⌝ قــســم الـبــرمجــة ┋💻⌞ ⇊*
*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*

*💻┊⇇ 『 إحــســب-الــحــروف 』*  
*📎┊⇇ 『 إخــتـصــار-إنــشــاء 』*  
*📎┊⇇ 『 إخــتـصــار 』*  
*🌐┊⇇ 『 أيــ-بــي 』*  
*📶┊⇇ 『 بــنــج 』*  
*📄┊⇇ 『 بــي-دي-اف 』*  
*✨┊⇇ 『 تــشــويــش 』*  
*🧪┊⇇ 『 دي-أن-أس 』*  
*🔍┊⇇ 『 فــحــص-الـمــوقــع 』*  
*🧾┊⇇ 『 هــيــدر 』*

*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*

> ⚡ بــوتــك مـع *『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 』*  
> دائــمــاً فــي أمــان وخـدمــة 💻
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جــارٍ إرســال قــســم الــبــرمجــة... ⏳💻_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '💻', key: m.key } });
};

handler.command = /^قسم-برمجه$/i;
handler.tags = ["بودي"];
handler.help = ["قسم-برمجه"];

export default handler;