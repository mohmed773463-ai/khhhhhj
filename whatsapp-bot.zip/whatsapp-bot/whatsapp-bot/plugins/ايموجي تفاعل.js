let owner = '967773463719'

// اوامر التشغيل والايقاف
let handler = async (m, { isAdmin, command }) => {

global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
let chat = global.db.data.chats[m.chat]

let sender = m.sender.split('@')[0]
let isOwner = sender === owner

if (!(isOwner || isAdmin))
return m.reply('❌ هذا الأمر للمشرفين والمطور فقط')

if (chat.emojiReact === undefined) chat.emojiReact = false

if (command === 'تشغيل-تفاعل-ايموجي') {
chat.emojiReact = true
return m.reply('✅ تم تشغيل تفاعل الإيموجي')
}

if (command === 'ايقاف-تفاعل-ايموجي') {
chat.emojiReact = false
return m.reply('❌ تم إيقاف تفاعل الإيموجي')
}

}

handler.command = ['تشغيل-تفاعل-ايموجي','ايقاف-تفاعل-ايموجي']
handler.group = true
handler.tags = ['group']
handler.help = ['تشغيل-تفاعل-ايموجي']

// التفاعل التلقائي
handler.before = async function (m, { conn }) {

if (!m.isGroup) return
if (!m.message) return
if (m.fromMe) return

global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
let chat = global.db.data.chats[m.chat]

if (!chat.emojiReact) return

let emojis = [
'😂','🤣','😹','🔥','💀','😎','😏','🤡','🥶','🤯',
'😴','😡','😳','👀','❤️','👍','👏','🤝','😅','😁',
'😆','😜','🤪','😈','💯','✨','🌚','🫡'
]

let emoji = emojis[Math.floor(Math.random() * emojis.length)]

await conn.sendMessage(m.chat, {
react: {
text: emoji,
key: m.key
}
})

}

export default handler