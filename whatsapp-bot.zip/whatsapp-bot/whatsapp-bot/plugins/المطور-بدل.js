import fs from 'fs';
import path from 'path';

const allowedIdentifiers = [
  '967773463719',
  '967784808742',
  '196211688661063',
  '195193932370046'
];

const handler = async (m, { conn, text }) => {
  const emoji = '💀';
  const signature = 'بـــــ𝑘𝑖𝑟𝑜ـــــوت 💀';

  const isAllowed = allowedIdentifiers.some(id => m.sender.includes(id));
  if (!isAllowed) {
    await conn.sendMessage(m.chat, { text: `${emoji} ❌ يا حب هذا الأمر للمطور كيرو بس.\n\n${signature}` }, { quoted: m });
    return;
  }

  if (!text || !text.includes('|')) {
    await conn.sendMessage(m.chat, { text: `${emoji} ⚠️ الاستخدام: *.بدل قديم|جديد*\n\n${signature}` }, { quoted: m });
    return;
  }

  const [oldWord, newWord] = text.split('|').map(s => s.trim());
  const basePath = './plugins';
  const files = fs.readdirSync(basePath).filter(file => file.endsWith('.js'));
  
  let changedFiles = 0;
  let fileList = [];

  for (let file of files) {
    const filePath = path.join(basePath, file);
    try {
      let content = fs.readFileSync(filePath, 'utf-8');
      if (content.includes(oldWord)) {
        const newContent = content.split(oldWord).join(newWord);
        fs.writeFileSync(filePath, newContent, 'utf-8');
        changedFiles++;
        fileList.push(file); // حفظ اسم الملف المعدل
      }
    } catch (err) { console.error(err) }
  }

  if (changedFiles === 0) {
    return m.reply(`${emoji} لم يتم العثور على الكلمة "${oldWord}" في أي ملف.`);
  }

  // 1. إرسال الرسالة الأولى فيها الأسماء
  let initialMsg = `${emoji} ✅ تم التعديل في ${changedFiles} ملف/ملفات:\n\n`
  initialMsg += fileList.map((f, i) => `${i + 1} - ${f}`).join('\n')
  initialMsg += `\n\n${signature}`

  const sentMsg = await conn.sendMessage(m.chat, { text: initialMsg }, { quoted: m });

  // 2. الانتظار لمدة 5 ثوانٍ ثم تعديل الرسالة لحذف الأسماء
  setTimeout(async () => {
    let finalMsg = `${emoji} ✅ تم بنجاح يا مطورنا كـيـرو!\n\n`
    finalMsg += `📝 استبدال: "${oldWord}" بـ "${newWord}"\n`
    finalMsg += `📁 إجمالي الملفات المعدلة: ${changedFiles}\n\n`
    finalMsg += `${signature}`
    
    await conn.editMessage(m.chat, sentMsg.key, finalMsg);
  }, 5000); // 5000 ميللي ثانية = 5 ثوانٍ

};

handler.help = ['بدل'];
handler.tags = ['owner'];
handler.command = /^بدل$/i;

export default handler;
