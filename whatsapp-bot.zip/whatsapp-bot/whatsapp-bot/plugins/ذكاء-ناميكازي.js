import axios from 'axios';

let handler = async (m, { text, command }) => {
  if (!text) {
    let usageExamples = {
      chatbot: '💀 *طريقة الاستخدام:*\nاكتب سؤالك بعد الأمر مثل:\n.chatbot من هو ناروتو أوزوماكي؟',
      ناميكازي: '💀 *طريقة الاستخدام:*\nاكتب سؤالك بعد الأمر مثل:\nناميكازي ما معنى الشينوبي؟'
    };
    
    return m.reply(`${usageExamples[command] || '💀 اكتب سؤالك بعد الأمر بشكل صحيح.'}\n\nبـــــ𝑘𝑖𝑟𝑜ـــــوت💀`);
  }

  try {
    let { data } = await axios.get(`https://www.abella.icu/onlinechatbot?q=${encodeURIComponent(text + ' جاوبني بالعربية فقط')}`);
    if (data?.data?.answer?.data) {
      m.reply(`💀 *الإجابة:*\n${data.data.answer.data}\n\nبـــــ𝑘𝑖𝑟𝑜ـــــوت💀`);
    } else {
      m.reply(`💀 لم أتمكن من العثور على إجابة.\n\nبـــــ𝑘𝑖𝑟𝑜ـــــوت💀`);
    }
  } catch (e) {
    m.reply(`💀 حدث خطأ أثناء الاتصال بالخادم.\n\nبـــــ𝑘𝑖𝑟𝑜ـــــوت💀`);
  }
};

handler.help = ['chatbot', 'ناميكازي'].map(v => v + ' <سؤالك>');
handler.command = ['chatbot', 'ناميكازي'];
handler.tags = ['ai'];

export default handler;