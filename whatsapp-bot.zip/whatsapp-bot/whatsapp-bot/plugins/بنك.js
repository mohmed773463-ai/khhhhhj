import { prepareWAMessageMedia } from '@whiskeysockets/baileys'

let handler = async (m, { conn, args, command, text, usedPrefix }) => {
    let user = global.db.data.users[m.sender]
    // تعريف جلسات التحويل المؤقتة إذا لم تكن موجودة
    if (!global.db.data.transfers) global.db.data.transfers = {}

    // التأكد من وجود القيم الأساسية (نقاط ومال وبنك)
    if (typeof user.money === 'undefined') user.money = 0
    if (typeof user.exp === 'undefined') user.exp = 0
    if (typeof user.bank === 'undefined') user.bank = 0

    // حساب الثروة الكلية (نقاط + مال)
    let totalWealth = user.money + user.exp + user.bank

    // نظام الألقاب الفخم
    let rank = '📉 فقير معدم'
    if (totalWealth > 10000) rank = '🪙 كادح'
    if (totalWealth > 50000) rank = '💰 تاجر صغير'
    if (totalWealth > 200000) rank = '🏢 مستثمر'
    if (totalWealth > 1000000) rank = '💎 مليونير'
    if (totalWealth > 10000000) rank = '👑 ملك الاقتصاد'

    // جلب صورة البروفايل
    let pp = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://qu.ax/YfAbL.jpg')
    const media = await prepareWAMessageMedia({ image: { url: pp } }, { upload: conn.waUploadToServer })

    /* 🏦 لوحة البنك الرئيسية */
    if (command == "بنك") {
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 إيداع سريع", id: `${usedPrefix}ايداع` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💸 سحب سريع", id: `${usedPrefix}سحب` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏆 قائمة الأغنياء", id: `${usedPrefix}الأغنياء` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔄 تحويل", id: `${usedPrefix}تحويل` }) }
        ]

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: `🏦 نـظـام الـبـنـك الـمـركـزي`,
                            hasMediaAttachment: true,
                            imageMessage: media.imageMessage
                        },
                        body: {
                            text: `*👤 المستخدم:* ${m.pushName}\n*🎖️ اللقب:* ${rank}\n\n*🪙 رصيدك البنكي:* ${user.bank}$\n*💰 كاش (نقاط + مال):* ${user.money + user.exp}$\n\n*📊 حالة السوق:* ${['⚖️ مستقر', '🔥 طفرة', '📉 هبوط'].sort(() => Math.random() - 0.5)[0]}`
                        },
                        footer: { text: "بـــــ𝑘𝑖𝑟𝑜ـــــوت" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {})
    }

    /* 💰 نظام الإيداع (Deposit) */
    if (command == "ايداع") {
        if (!args[0]) {
            let buttons = [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🪙 1000", id: `${usedPrefix}ايداع 1000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🪙 5000", id: `${usedPrefix}ايداع 5000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 إيداع الكل", id: `${usedPrefix}ايداع الكل` }) }
            ]
            return conn.relayMessage(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: { title: "💰 الإيداع الآمن" },
                            body: { text: `اختر المبلغ لإيداعه في خزنة البنك\nرصيدك المتاح: ${user.money + user.exp}$` },
                            nativeFlowMessage: { buttons }
                        }
                    }
                }
            }, {})
        }

        let amount = args[0] === 'الكل' ? (user.money + user.exp) : parseInt(args[0])
        if (isNaN(amount) || amount <= 0) return m.reply('⚠️ أدخل مبلغا صحيحاً!')

        if ((user.money + user.exp) < amount) return m.reply('❌ لا تملك هذا القدر من المال!')

        // الخصم من المال أولاً ثم النقاط
        if (user.money >= amount) {
            user.money -= amount
        } else {
            let remaining = amount - user.money
            user.money = 0
            user.exp -= remaining
        }

        user.bank += amount
        return m.reply(`✅ تم إيداع *${amount}$* في حسابك بنجاح!`)
    }

    /* 💸 نظام السحب (Withdraw) */
    if (command == "سحب") {
        if (!args[0]) {
            let buttons = [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🪙 1000", id: `${usedPrefix}سحب 1000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🪙 5000", id: `${usedPrefix}سحب 5000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 سحب الكل", id: `${usedPrefix}سحب الكل` }) }
            ]
            return conn.relayMessage(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: { title: "💸 سحب الأموال" },
                            body: { text: `اختر المبلغ المراد سحبه إلى محفظتك\nرصيد البنك: ${user.bank}$` },
                            nativeFlowMessage: { buttons }
                        }
                    }
                }
            }, {})
        }

        let amount = args[0] === 'الكل' ? user.bank : parseInt(args[0])
        if (isNaN(amount) || amount <= 0) return m.reply('⚠️ أدخل مبلغا صحيحاً!')
        if (user.bank < amount) return m.reply('❌ رصيد البنك لا يكفي!')

        user.bank -= amount
        user.money += amount
        return m.reply(`💸 تم سحب *${amount}$* إلى محفظتك!`)
    }

    /* 🏆 قائمة الأثرياء */
    if (command == "الأغنياء") {
        let users = Object.entries(global.db.data.users)
        let top = users
            .map(([jid, data]) => ({ jid, money: (data.money || 0) + (data.bank || 0) + (data.exp || 0) }))
            .sort((a, b) => b.money - a.money)
            .slice(0, 10)

        let txt = `*🏆 قائمة أقوى 10 اقتصاداً في البوت*\n\n`
        for (let i = 0; i < top.length; i++) {
            let name = await conn.getName(top[i].jid)
            let emoji = i == 0 ? '👑' : i == 1 ? '🥈' : i == 2 ? '🥉' : '👤'
            txt += `${emoji} *${i + 1}. ${name}*\n   💰 ثروة: ${top[i].money}$\n\n`
        }
        return m.reply(txt)
    }

    /* 🔄 نظام التحويل (Transfer) */
    if (command == "تحويل") {
        // جلسة التحويل: ننتظر الرد بمنشن الشخص
        if (!args[0]) {
            // تخزين مؤقت لعملية التحويل لهذا المستخدم
            global.db.data.transfers[m.sender] = { step: 'waiting_mention', amount: null }
            return m.reply(`*🔁 نظام التحويل*\n\nالرجاء الرد على هذه الرسالة مع منشن الشخص الذي تريد التحويل إليه.\nمثال: @${m.sender.split('@')[0]}\n\n📌 *ملاحظة:* يمكنك فقط التحويل إلى أشخاص آخرين، وليس إلى نفسك.`)
        } else if (args[0].toLowerCase() === 'الغاء') {
            if (global.db.data.transfers[m.sender]) delete global.db.data.transfers[m.sender]
            return m.reply('❌ تم إلغاء عملية التحويل.')
        }

        // إذا كان هناك جلسة تحويل نشطة، نتعامل معها
        if (global.db.data.transfers[m.sender] && global.db.data.transfers[m.sender].step === 'waiting_mention') {
            // نحاول استخراج المنشن من الرسالة الحالية
            let mentioned = m.mentionedJid && m.mentionedJid[0]
            if (!mentioned) {
                return m.reply('⚠️ يرجى منشن الشخص الذي تريد التحويل إليه في ردك.\nمثال: @' + m.sender.split('@')[0])
            }
            if (mentioned === m.sender) {
                delete global.db.data.transfers[m.sender]
                return m.reply('❌ لا يمكنك التحويل إلى نفسك!')
            }

            // تخزين المستخدم المستهدف
            global.db.data.transfers[m.sender].target = mentioned
            global.db.data.transfers[m.sender].step = 'waiting_amount'

            // رسالة بها أزرار لاختيار المبلغ
            let buttons = [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 1000", id: `${usedPrefix}تحويل 1000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 5000", id: `${usedPrefix}تحويل 5000` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 تحويل الكل", id: `${usedPrefix}تحويل الكل` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❌ إلغاء", id: `${usedPrefix}تحويل الغاء` }) }
            ]

            return conn.relayMessage(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: { title: "💸 تحويل الأموال" },
                            body: { text: `تم تحديد المستهدف: @${mentioned.split('@')[0]}\nالآن قم باختيار المبلغ الذي تريد تحويله.\n\n💰 رصيدك المتاح: ${user.money + user.exp}$` },
                            nativeFlowMessage: { buttons }
                        }
                    }
                }
            }, {})
        }

        // معالجة اختيار المبلغ (من الزر أو من الكتابة)
        let amount
        let targetUser = null

        // إذا كان هناك جلسة نشطة، نستخدم الهدف منها
        if (global.db.data.transfers[m.sender] && global.db.data.transfers[m.sender].target) {
            targetUser = global.db.data.transfers[m.sender].target
        }

        // تحديد المبلغ
        if (args[0] === 'الكل') {
            amount = user.money + user.exp
        } else {
            amount = parseInt(args[0])
            if (isNaN(amount) || amount <= 0) return m.reply('⚠️ أدخل مبلغا صحيحاً للتحويل!')
        }

        // التأكد من وجود المستهدف
        if (!targetUser) {
            // إذا لم يكن هناك جلسة، نبحث عن منشن في نفس الرسالة
            if (m.mentionedJid && m.mentionedJid[0]) {
                targetUser = m.mentionedJid[0]
                if (targetUser === m.sender) return m.reply('❌ لا يمكنك التحويل إلى نفسك!')
            } else {
                return m.reply(`⚠️ يرجى منشن الشخص المستلم.\nمثال: ${usedPrefix}تحويل 1000 @${m.sender.split('@')[0]}`)
            }
        }

        // التحقق من وجود المستخدم
        if (!global.db.data.users[targetUser]) {
            return m.reply('❌ المستخدم غير موجود في قاعدة البيانات!')
        }

        // التحقق من الرصيد
        let senderTotal = user.money + user.exp
        if (senderTotal < amount) {
            return m.reply(`❌ رصيدك غير كافٍ! لديك ${senderTotal}$ فقط.`)
        }

        // تنفيذ التحويل
        let target = global.db.data.users[targetUser]

        // خصم من المرسل (من المال أولاً ثم النقاط)
        if (user.money >= amount) {
            user.money -= amount
        } else {
            let remaining = amount - user.money
            user.money = 0
            user.exp -= remaining
        }

        // إضافة للمستلم (إلى المال)
        target.money += amount

        // تنظيف الجلسة
        delete global.db.data.transfers[m.sender]

        // إرسال إشعار للمرسل
        let senderName = m.pushName
        let targetName = await conn.getName(targetUser)
        await m.reply(`✅ *تم التحويل بنجاح!*\n\n📤 *المرسل:* ${senderName}\n📥 *المستلم:* ${targetName}\n💰 *المبلغ:* ${amount}$\n\n💬 *ملاحظة:* تم خصم المبلغ من رصيدك (نقاط + مال) وإضافته إلى رصيد المستلم.`)

        // إرسال إشعار للمستلم (إذا كان في نفس المجموعة أو المحادثة)
        try {
            await conn.sendMessage(targetUser, { text: `📢 *إشعار تحويل*\n\nلقد استلمت تحويلاً بقيمة *${amount}$* من @${m.sender.split('@')[0]}.\n\nشكراً لاستخدام نظام التحويل الآمن.`, mentions: [m.sender] })
        } catch (e) {
            console.log('فشل إرسال الإشعار للمستلم:', e)
        }
    }
}

handler.help = ["بنك"]
handler.tags = ["economy"]
handler.command = /^(بنك|ايداع|سحب|الأغنياء|تحويل)$/i

export default handler