import fetch from 'node-fetch';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const handler = async (m, { conn, usedPrefix }) => {
    
    // تفاعل بسيط
    await conn.sendMessage(m.chat, { react: { text: '📖', key: m.key } });

    try {
        const res = await fetch('https://raw.githubusercontent.com/Hyodu/Moon/main/database/API/Quran.txt');
        const content = await res.text();
        const videos = content.split('\n').filter(v => v.trim() !== ''); 
        const randomVideo = videos[Math.floor(Math.random() * videos.length)];

        if (!randomVideo) throw 'لم يتم العثور على روابط';

        var videoMsg = await prepareWAMessageMedia({ video: { url: randomVideo } }, { upload: conn.waUploadToServer });

        const interactiveMessage = {
            body: { text: '*القرآن الكريم 🕊️*\n\nاللهم اجعل القرآن ربيع قلوبنا ونور صدورنا.' },
            footer: { text: 'اضغط على الزر للمزيد' },
            header: {
                hasMediaAttachment: true,
                videoMessage: videoMsg.videoMessage,
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🎬 مقطع آخـر",
                            id: `${usedPrefix}فيديو-قرأن`
                        })
                    }
                ]
            }
        };        

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage,
                },
            },
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, '❌ حدث خطأ، تأكد من الاتصال بالإنترنت.', m);
    }    
}; 

handler.help = ['فيديو-قرأن'];
handler.tags = ['دين'];
handler.command = /^(فيديو-قرأن|ايات-فيديو|قران-فيديو)$/i;

export default handler;
