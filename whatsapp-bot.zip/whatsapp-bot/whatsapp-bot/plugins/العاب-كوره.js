import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';

const timeout = 60000;

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.obito = conn.obito || {};
    let id = m.chat;

    if (/^مجوب_/i.test(command)) {
        let obito = conn.obito[id];
        if (!obito) return; 

        let selectedAnswerIndex = parseInt(command.split('_')[1]);
        let selectedAnswer = obito.options[selectedAnswerIndex - 1];
        let isCorrect = obito.correctAnswer === selectedAnswer;

        if (isCorrect) {
            await conn.reply(m.chat, `✅ *إجابة صحيحة!*\n💰 الجائزة: 500xp`, m);
            if (global.db.data.users[m.sender]) global.db.data.users[m.sender].exp += 500;
            clearTimeout(obito.timer);
            delete conn.obito[id];
        } else {
            obito.attempts -= 1;
            if (obito.attempts > 0) {
                await conn.reply(m.chat, `❌ *إجابة خاطئة!*\nباقي لك ${obito.attempts} محاولة.`, m);
            } else {
                await conn.reply(m.chat, `💀 *انتهت المحاولات!*\nاللاعب هو: *${obito.correctAnswer}*`, m);
                clearTimeout(obito.timer);
                delete conn.obito[id];
            }
        }
    } else {
        if (conn.obito[id]) return conn.reply(m.chat, '⚠️ هناك لعبة جارية بالفعل!', m);

        try {
            const response = await fetch('https://raw.githubusercontent.com/Afghany/Games-Data/main/football.json');
            const footballData = await response.json();
            const item = footballData[Math.floor(Math.random() * footballData.length)];
            
            // تأكد من جلب رابط الصورة بشكل صحيح
            const imgUrl = item.img; 

            // تجهيز الخيارات
            let options = [item.name];
            while (options.length < 4) {
                let randomItem = footballData[Math.floor(Math.random() * footballData.length)].name;
                if (!options.includes(randomItem)) options.push(randomItem);
            }
            options.sort(() => Math.random() - 0.5);

            // تحسين معالجة الميديا لضمان الظهور
            let media;
            try {
                media = await prepareWAMessageMedia({ image: { url: imgUrl } }, { upload: conn.waUploadToServer });
            } catch (mediaError) {
                console.error("خطأ في رفع الصورة:", mediaError);
                return conn.reply(m.chat, "❌ فشل تحميل صورة اللاعب، حاول مجدداً.", m);
            }

            const interactiveMessage = {
                body: { text: `⚽ *لعبة خمن اللاعب*\n\nالوقت: 60 ثانية\nالجائزة: 500xp` },
                footer: { text: 'ᔕ卂ᗪ' },
                header: {
                    title: 'من هذا اللاعب؟',
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage
                },
                nativeFlowMessage: {
                    buttons: options.map((option, index) => ({
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: option,
                            id: `${usedPrefix}مجوب_${index + 1}`
                        })
                    }))
                }
            };

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: { interactiveMessage } }
            }, { userJid: conn.user.jid, quoted: m });

            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            conn.obito[id] = {
                correctAnswer: item.name,
                options: options,
                attempts: 2,
                timer: setTimeout(() => {
                    if (conn.obito[id]) {
                        conn.sendMessage(m.chat, { text: `⌛ انتهى الوقت! اللاعب هو: *${item.name}*` });
                        delete conn.obito[id];
                    }
                }, timeout)
            };
        } catch (e) {
            console.error(e);
            conn.reply(m.chat, '❌ فشل الاتصال بسيرفر البيانات.', m);
        }
    }
};

handler.help = ['كورة'];
handler.tags = ['العاب'];
handler.command = /^(كورة|كوره|مجوب_\d+)$/i;

export default handler;
