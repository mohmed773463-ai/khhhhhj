import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys'
import moment from 'moment-timezone'

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms % 3600000 / 60000)
    let s = Math.floor(ms % 60000 / 1000)
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

const handler = async (m, { conn }) => {
    let d = new Date(new Date() + 3600000)
    let locale = 'ar'
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
    let uptime = clockString(process.uptime() * 1000)
    let taguser = '@' + m.sender.split("@")[0]

    const snMessage = '*جارِ تجهيز القائمة...*'
    conn.fakeReply(m.chat, snMessage, '0@s.whatsapp.net', 'منور الحلو 👋', 'status@broadcast')
    await conn.sendMessage(m.chat, { react: { text: '👑', key: m.key } })

    const images = ['https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg']
    var messa = await prepareWAMessageMedia({ image: { url: images[0] } }, { upload: conn.waUploadToServer })

    await new Promise(resolve => setTimeout(resolve, 250))

    conn.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: `◦ مرحبا بك ${taguser} ◈─🕷️〘ᔕ卂ᗪ〙🕷️─◈\n📅 ${date}\n⏱ ${uptime}`
                    },
                    footer: { text: 'ᔕ卂ᗪ' },
                    header: {
                        title: '',
                        hasMediaAttachment: true,
                        imageMessage: messa.imageMessage
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '『 قائمة الأوامر 』',
                                    sections: [
                                        {
                                            title: '❪ أقسام البوت ❫',
                                            rows: [
                                                { title: '📡 قسم البحث', id: '.قسم-البحث' },
                                                { title: '🎮 قسم الفعاليات', id: '.قسم-الفعاليات' },
                                                { title: '🎲 قسم الترفيه', id: '.قسم-الترفيه' },
                                                { title: '💻 قسم البرمجة', id: '.قسم-برمجه' },
                                                { title: '🌍 قسم الدول', id: '.قسم-دول' },
                                                { title: '💬 قسم المجموعات', id: '.قسم-جروب' },
                                                { title: '📥 قسم التحميل', id: '.قسم-التحميلات' },
                                                { title: '🎙️ قسم الصوتيات', id: '.قسم-صوتيات' },
                                                { title: '🧰 قسم الأدوات', id: '.قسم-الادوات' },
                                                { title: '🕌 القسم الديني', id: '.قسم-الدين' },
                                                { title: '🧠 قسم الذكاء', id: '.قسم-الذكاء' },
                                                { title: '🎮 قسم الألعاب', id: '.ق1' },
                                                { title: '👮 قسم المشرفين', id: '.ق3' },
                                                { title: '📜 القوانين', id: '.القواعد' },
                                                { title: '👑 قسم المطور', id: '.مطور' }
                                            ]
                                        }
                                    ]
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "👑 المطور",
                                    id: ".مطور"
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {})
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['اوامر', 'menu', 'الاوامر', 'القائمة']

export default handler

// ========================
// الأقسام
// ========================

async function sendSection(m, conn, name) {
    await conn.sendMessage(m.chat, { text: `⚡ جاري تجهيز ${name}...` }, { quoted: m })
    setTimeout(async () => {
        await conn.sendMessage(m.chat, { text: `✅ ${name}\n\nتم التجهيز بنجاح` }, { quoted: m })
    }, 1000)
}

handler['قسم-البحث'] = (m, { conn }) => sendSection(m, conn, "قسم البحث")
handler['قسم-الفعاليات'] = (m, { conn }) => sendSection(m, conn, "قسم الفعاليات")
handler['قسم-الترفيه'] = (m, { conn }) => sendSection(m, conn, "قسم الترفيه")
handler['قسم-برمجه'] = (m, { conn }) => sendSection(m, conn, "قسم البرمجة")
handler['قسم-دول'] = (m, { conn }) => sendSection(m, conn, "قسم الدول")
handler['قسم-جروب'] = (m, { conn }) => sendSection(m, conn, "قسم المجموعات")
handler['قسم-التحميلات'] = (m, { conn }) => sendSection(m, conn, "قسم التحميل")
handler['قسم-صوتيات'] = (m, { conn }) => sendSection(m, conn, "قسم الصوتيات")
handler['قسم-الادوات'] = (m, { conn }) => sendSection(m, conn, "قسم الأدوات")
handler['قسم-الدين'] = (m, { conn }) => sendSection(m, conn, "القسم الديني")
handler['قسم-الذكاء'] = (m, { conn }) => sendSection(m, conn, "قسم الذكاء الاصطناعي")
handler['قسم-المطور'] = (m, { conn }) => sendSection(m, conn, "قسم المطور")
handler['ق1'] = (m, { conn }) => sendSection(m, conn, "قسم الألعاب")
handler['ق3'] = (m, { conn }) => sendSection(m, conn, "قسم المشرفين")

handler['القواعد'] = async (m, { conn }) => {
    await conn.sendMessage(m.chat, { text: "📜 جاري ارسال القوانين..." }, { quoted: m })
    await conn.sendMessage(m.chat, {
        text: `📜 قوانين البوت\n\n1- احترام الجميع\n2- ممنوع السب\n3- ممنوع الروابط`
    }, { quoted: m })
}
