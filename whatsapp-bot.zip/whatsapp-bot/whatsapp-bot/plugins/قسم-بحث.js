const handler = async (m, { conn }) => {

    const imageUrl = "https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg";

    const messageText = `
╔══════════════════╗
  ✦ مرحباً بك يا 【 ${m.pushName} 】 ✦
        في قسم البحث 🔍
╚══════════════════╝

╔══════ ⌬ ══════╗
🔍 ⌊ IP ⌉
🔍 ⌊ اخبار انمي ⌉
🔍 ⌊ اخبار كره ⌉
🔍 ⌊ بحث تيك ⌉
🔍 ⌊ دروس ⌉
🔍 ⌊ فري فاير ⌉
🔍 ⌊ مانجا ⌉
🔍 ⌊ ناسا ⌉
╚══════ ⌬ ══════╝

> بـــــ𝑘𝑖𝑟𝑜ـــــوت 💗💛
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جاري إرسال القسم....... 🔍_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '💀', key: m.key } });
};

handler.command = /^قسم-بحث$/i;
handler.tags = ["spider"];
handler.help = ["قسم-بحث"];

export default handler;