const handler = async (m, { conn }) => {

    const imageUrl = "https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg";

    const messageText = `

*『 مـــرحــبــاً بــك يــا ⌊ ${m.pushName} ⌉ فــي 『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 』』*

*⌝ قــســم الــصــوتــيــات ┋💀⌞ ⇊*
*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*

🗿┊⇇『 عــمــيــق 』
⛓‍💥┊⇇『 مـنـفـوخ 』
🎐┊⇇『 تــخــيــن 』
⚽┊⇇『 صــاخــب 』
📿┊⇇『 ســريــع 』
📍┊⇇『 تـخـيـنـن 』
🗃️┊⇇『 رفــيــع 』
📬┊⇇『 تـقـطـيـع 』
📕┊⇇『 روبــــوت 』
📆┊⇇『 بــطــيء 』
🗞️┊⇇『 نــاعــم 』
🐿️┊⇇『 سـنـجـاب 』

*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*
> 『 بـــــ𝑘𝑖𝑟𝑜ـــــوت 💗💛 』
`.trim();

    await conn.sendMessage(m.chat, { text: "*✦ جـــارٍ إرســال قــســم الــصــوتــيــات....... 💗📿*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '💀', key: m.key } });
};

handler.command = /^قسم-الصوتيات$/i;
handler.tags = ["بــودي"];
handler.help = ["بــودي"];

export default handler;