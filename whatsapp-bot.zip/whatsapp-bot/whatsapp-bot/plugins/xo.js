let games = {}

function render(b){
const e={
X:"❌",O:"⭕",
1:"1️⃣",2:"2️⃣",3:"3️⃣",
4:"4️⃣",5:"5️⃣",6:"6️⃣",
7:"7️⃣",8:"8️⃣",9:"9️⃣"
}
return `${e[b[0]]}|${e[b[1]]}|${e[b[2]]}
──────
${e[b[3]]}|${e[b[4]]}|${e[b[5]]}
──────
${e[b[6]]}|${e[b[7]]}|${e[b[8]]}`
}

function win(b,p){
return(
(b[0]==p&&b[1]==p&&b[2]==p)||
(b[3]==p&&b[4]==p&&b[5]==p)||
(b[6]==p&&b[7]==p&&b[8]==p)||
(b[0]==p&&b[3]==p&&b[6]==p)||
(b[1]==p&&b[4]==p&&b[7]==p)||
(b[2]==p&&b[5]==p&&b[8]==p)||
(b[0]==p&&b[4]==p&&b[8]==p)||
(b[2]==p&&b[4]==p&&b[6]==p)
)
}

async function sendBoard(conn,m,room){

let buttons=[]

for(let i=1;i<=9;i++){
buttons.push({
name:"quick_reply",
buttonParamsJson:JSON.stringify({
display_text:`${i}`,
id:`.xo ${i}`
})
})
}

await conn.relayMessage(m.chat,{
viewOnceMessage:{
message:{
interactiveMessage:{
header:{title:"🎮 لعبة XO"},
body:{text:`${render(room.board)}

الدور الآن
${room.turn=="X"?"❌ اللاعب الأول":"⭕ اللاعب الثاني"}`},
footer:{text:"بـــــ𝑘𝑖𝑟𝑜ـــــوت"},
nativeFlowMessage:{buttons}
}
}
}
},{})
}

let handler = async (m,{conn,args,command})=>{

let text = m.text || ""
let room = games[m.chat]

/* بدء اللعبة */

if(!room && (command=="xo"||text==".لعبه xo")){

games[m.chat]={
X:m.sender,
O:null,
board:["1","2","3","4","5","6","7","8","9"],
turn:"X"
}

return conn.relayMessage(m.chat,{
viewOnceMessage:{
message:{
interactiveMessage:{
header:{title:"🎮 لعبة XO"},
body:{text:`تم إنشاء لعبة

❌ اللاعب الأول
@${m.sender.split("@")[0]}

اضغط زر دخول`},
footer:{text:"بـــــ𝑘𝑖𝑟𝑜ـــــوت"},
nativeFlowMessage:{
buttons:[
{
name:"quick_reply",
buttonParamsJson:JSON.stringify({
display_text:"دخول",
id:".join_xo"
})
}
]
}
}
}
}
},{mentions:[m.sender]})
}

/* دخول لاعب */

if(text==".join_xo" && room && !room.O){

room.O=m.sender
return sendBoard(conn,m,room)
}

/* اللعب */

if(text.startsWith(".xo")){

if(!room) return

let pos=parseInt(text.split(" ")[1])

if(!pos) return

let player = room.turn=="X"?room.X:room.O

if(m.sender!==player)
return conn.reply(m.chat,"ليس دورك",m)

if(room.board[pos-1]=="X"||room.board[pos-1]=="O")
return conn.reply(m.chat,"المكان مستخدم",m)

room.board[pos-1]=room.turn

if(win(room.board,room.turn)){

conn.reply(m.chat,
`🏆 فاز اللاعب
@${m.sender.split("@")[0]}

${render(room.board)}`,m,{mentions:[m.sender]})

delete games[m.chat]
return
}

if(!room.board.includes("1")&&!room.board.includes("2")&&!room.board.includes("3")&&!room.board.includes("4")&&!room.board.includes("5")&&!room.board.includes("6")&&!room.board.includes("7")&&!room.board.includes("8")&&!room.board.includes("9")){

conn.reply(m.chat,`تعادل

${render(room.board)}`,m)

delete games[m.chat]
return
}

room.turn = room.turn=="X"?"O":"X"

sendBoard(conn,m,room)

}

}

handler.help=["xo"]
handler.tags=["game"]
handler.command=/^(xo|لعبه xo)$/i
handler.group=true

export default handler