const handler = async (m, { conn }) => {

    const imageUrl = "https://i.postimg.cc/Wb3SW4Lf/bot-image.jpg";

    const messageText = `
*『 مرحبا بك يا  ⌊ ${m.pushName} ⌉ في بـــــ𝑘𝑖𝑟𝑜ـــــوتـــوت 』*

*⌝ قسم الدين ┋🕋⌞ ⇊*
*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*
*🕋┊⇇『اذكار-الصباح』*
*🕋┊⇇『اذكار-المساء』*
*🕋┊⇇『اذكار-النوم』*
*🕋┊⇇『دعاء』*
*🕋┊⇇『فيديو-قرآن』*
*🕋┊⇇『مواقيت_الصلاة』*
*🕋┊⇇『خطبة』*
*🕋┊⇇『دعاء-رمضان』*
*🕋┊⇇『الله』*
*🕋┊⇇『حديث』*
*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*

> بـــــ𝑘𝑖𝑟𝑜ـــــوت 💗💛
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جاري إرسال القسم....... 💗📿_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🕋', key: m.key } });
};

handler.command = /^قسم-الدين$/i;
handler.tags = ["بــودي"];
handler.help = ["قسم-الدين"];

export default handler;