// owner-pro-max.js
// 👑 أوامر المطور مع أزرار تفاعلية

import { exec } from 'child_process';
import { promisify } from 'util';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const execAsync = promisify(exec);

// 🔐 إعدادات المطور الأساسية
const MAIN_OWNER = '967773463719@s.whatsapp.net';
const OWNER_NAME = 'ᔕ卂ᗪ';

// 🗂️ إعدادات التحكم بالمجموعات
if (!global.db.data.settings) global.db.data.settings = {};
if (!global.db.data.settings.groupControl) {
    global.db.data.settings.groupControl = {
        botEnabled: true,
        allowedGroups: [],
        bannedGroups: [],
        antilink: false,
        antiarabic: false,
        welcome: false,
        goodbye: false,
        muteGroups: [],
    };
}

let handler = async (m, { conn, args, command, usedPrefix, isOwner, isROwner, text, participants }) => {
    
    // التحقق من الصلاحية
    if (!isOwner && m.sender !== MAIN_OWNER) {
        await m.react('❌');
        return m.reply('⛔ *هذا الأمر فقط للمطور الأساسي*\n> أنت لست مطور هذا البوت');
    }

    // ======================= قائمة الأوامر الرئيسية =======================
    if (command === "اعدادات-المطور" || command === "اوامر-المطور") {
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🤖 التحكم بالبوت", id: `${usedPrefix}قايمة-البوت` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👥 إدارة المطورين", id: `${usedPrefix}قايمة-المطورين` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📊 التحكم بالمجموعات", id: `${usedPrefix}قايمة-المجموعات` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚙️ إدارة المجموعة", id: `${usedPrefix}قايمة-الادارة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🚫 الحظر والكتم", id: `${usedPrefix}قايمة-الحظر` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📈 إحصائيات البوت", id: `${usedPrefix}احصائيات` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "👑 لوحة تحكم المطور" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ ✨ مرحباً *${OWNER_NAME}*\n┃\n┃ 📊 *التحكم الكامل بالبوت*\n┃\n┃ اختر القائمة المناسبة:\n┃\n╰━━━━━━━━━━━━━━━╯` },
                        footer: { text: "اضغط على الزر للتحكم 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= قائمة التحكم بالبوت =======================
    if (command === "قايمة-البوت") {
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📢 إذاعة", id: `${usedPrefix}اذاعة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔄 إعادة تشغيل", id: `${usedPrefix}ريستارت` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💀 إيقاف البوت", id: `${usedPrefix}اطفاء` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔄 تحديث البوت", id: `${usedPrefix}تحديث` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📛 تغيير الاسم", id: `${usedPrefix}تغيير-اسم` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🖼️ تغيير الصورة", id: `${usedPrefix}تغيير-صورة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع", id: `${usedPrefix}اعدادات-المطور` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "🤖 التحكم بالبوت" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ *أوامر التحكم بالبوت*\n┃\n┃ • إذاعة: إرسال رسالة للجميع\n┃ • إعادة تشغيل: ريستارت البوت\n┃ • إيقاف: إطفاء البوت\n┃ • تحديث: سحب آخر تحديث\n┃ • تغيير الاسم/الصورة\n┃\n╰━━━━━━━━━━━━━━━╯` },
                        footer: { text: "اختر الأمر 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= قائمة المطورين =======================
    if (command === "قايمة-المطورين") {
        let owners = global.db.data.settings.owners || [MAIN_OWNER];
        let ownersList = owners.map(o => `• @${o.split('@')[0]}`).join('\n');
        
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "➕ إضافة مطور", id: `${usedPrefix}اضافة-مطور` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "➖ حذف مطور", id: `${usedPrefix}حذف-مطور` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 تعيين مالك", id: `${usedPrefix}تعيين-مالك` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📋 قائمة المطورين", id: `${usedPrefix}قائمة-المطورين` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع", id: `${usedPrefix}اعدادات-المطور` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "👥 إدارة المطورين" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ *المطورين الحاليين*\n┃\n${ownersList || '┃ لا يوجد مطورين'}\n┃\n╰━━━━━━━━━━━━━━━╯\n\n*اختر الإجراء المناسب 👇*` },
                        footer: { text: "اضغط على الزر" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= قائمة التحكم بالمجموعات =======================
    if (command === "قايمة-المجموعات") {
        let s = global.db.data.settings.groupControl;
        let status = s.botEnabled ? '✅ مفعل' : '❌ معطل';
        
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✅ تشغيل البوت", id: `${usedPrefix}تشغيل-البوت` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "❌ إطفاء البوت", id: `${usedPrefix}اطفاء-البوت` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔗 تفعيل حماية الروابط", id: `${usedPrefix}تفعيل-حماية` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔓 تعطيل حماية الروابط", id: `${usedPrefix}تعطيل-حماية` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📋 حالة المجموعات", id: `${usedPrefix}حالة-المجموعات` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع", id: `${usedPrefix}اعدادات-المطور` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "📊 التحكم بالمجموعات" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ *حالة البوت:* ${status}\n┃ *حماية الروابط:* ${s.antilink ? '✅' : '❌'}\n┃\n┃ *المجموعات المستثناة:* ${s.allowedGroups.length}\n┃ *المجموعات المحظورة:* ${s.bannedGroups.length}\n┃ *المجموعات المكتومة:* ${s.muteGroups.length}\n┃\n╰━━━━━━━━━━━━━━━╯` },
                        footer: { text: "اختر الإجراء 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= قائمة إدارة المجموعة الحالية =======================
    if (command === "قايمة-الادارة") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 رفع مشرف", id: `${usedPrefix}رفع-مشرف` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⬇️ تنزيل مشرف", id: `${usedPrefix}تنزيل-مشرف` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👢 طرد عضو", id: `${usedPrefix}طرد-عضو` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔒 إغلاق المجموعة", id: `${usedPrefix}اغلاق-المجموعة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔓 فتح المجموعة", id: `${usedPrefix}فتح-المجموعة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔗 رابط المجموعة", id: `${usedPrefix}رابط-المجموعة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع", id: `${usedPrefix}اعدادات-المطور` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "⚙️ إدارة المجموعة" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ *أوامر إدارة المجموعة*\n┃\n┃ • رفع/تنزيل مشرف\n┃ • طرد عضو\n┃ • إغلاق/فتح المجموعة\n┃ • رابط المجموعة\n┃\n╰━━━━━━━━━━━━━━━╯` },
                        footer: { text: "اختر الأمر 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= قائمة الحظر والكتم =======================
    if (command === "قايمة-الحظر") {
        let buttons = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🚫 حظر مستخدم", id: `${usedPrefix}حظر-مستخدم` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✅ فك حظر", id: `${usedPrefix}فك-حظر` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔇 كتم المجموعة", id: `${usedPrefix}كتم-مجموعة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔊 فك كتم", id: `${usedPrefix}فك-كتم` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📋 المحظورين", id: `${usedPrefix}المحظورين` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔇 المجموعات المكتومة", id: `${usedPrefix}المكتومة` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع", id: `${usedPrefix}اعدادات-المطور` }) }
        ];

        return conn.relayMessage(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "🚫 الحظر والكتم" },
                        body: { text: `╭━━━━━━━━━━━━━━━╮\n┃ *أوامر الحظر والكتم*\n┃\n┃ • حظر/فك حظر مستخدم\n┃ • كتم/فك كتم مجموعة\n┃ • عرض المحظورين\n┃ • عرض المجموعات المكتومة\n┃\n╰━━━━━━━━━━━━━━━╯` },
                        footer: { text: "اختر الأمر 👇" },
                        nativeFlowMessage: { buttons }
                    }
                }
            }
        }, {});
    }

    // ======================= أوامر تحتاج إدخال (تعمل بالرد أو المنشن) =======================
    
    // أمر الإذاعة - يطلب النص
    if (command === "اذاعة") {
        return m.reply('📢 *أمر الإذاعة*\n\nالرجاء الرد على هذه الرسالة وإرسال النص الذي تريد إذاعته.\n\nمثال: مرحباً بالجميع');
    }
    
    // أمر تغيير اسم البوت
    if (command === "تغيير-اسم") {
        return m.reply('📛 *تغيير اسم البوت*\n\nالرجاء الرد على هذه الرسالة وإرسال الاسم الجديد.\n\nمثال: بوت كيرو');
    }
    
    // أمر تغيير صورة البوت
    if (command === "تغيير-صورة") {
        return m.reply('🖼️ *تغيير صورة البوت*\n\nالرجاء الرد على هذه الرسالة وإرسال الصورة الجديدة.');
    }
    
    // أمر إضافة مطور
    if (command === "اضافة-مطور") {
        return m.reply('➕ *إضافة مطور جديد*\n\nالرجاء الرد على هذه الرسالة مع منشن الشخص أو رقمه.\n\nمثال: @المستخدم');
    }
    
    // أمر حذف مطور
    if (command === "حذف-مطور") {
        return m.reply('➖ *حذف مطور*\n\nالرجاء الرد على هذه الرسالة مع منشن المطور.\n\nمثال: @المطور');
    }
    
    // أمر تعيين مالك
    if (command === "تعيين-مالك") {
        return m.reply('👑 *تعيين مالك جديد*\n\nالرجاء الرد على هذه الرسالة مع منشن الشخص أو رقمه.\n\n⚠️ تحذير: هذا سيجعل الشخص مالكاً أساسياً!');
    }
    
    // أمر رفع مشرف
    if (command === "رفع-مشرف") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        return m.reply('👑 *رفع مشرف*\n\nالرجاء الرد على هذه الرسالة مع منشن الشخص.\n\nمثال: @المستخدم');
    }
    
    // أمر تنزيل مشرف
    if (command === "تنزيل-مشرف") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        return m.reply('⬇️ *تنزيل مشرف*\n\nالرجاء الرد على هذه الرسالة مع منشن المشرف.\n\nمثال: @المشرف');
    }
    
    // أمر طرد عضو
    if (command === "طرد-عضو") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        return m.reply('👢 *طرد عضو*\n\nالرجاء الرد على هذه الرسالة مع منشن العضو.\n\nمثال: @العضو');
    }
    
    // أمر حظر مستخدم
    if (command === "حظر-مستخدم") {
        return m.reply('🚫 *حظر مستخدم*\n\nالرجاء الرد على هذه الرسالة مع منشن الشخص.\n\nمثال: @المستخدم');
    }
    
    // أمر فك حظر
    if (command === "فك-حظر") {
        return m.reply('✅ *فك حظر*\n\nالرجاء الرد على هذه الرسالة مع منشن المحظور.\n\nمثال: @المستخدم');
    }
    
    // ======================= الأوامر التنفيذية (بتعمل مباشرة مع الرد) =======================
    
    // معالجة الردود للأوامر التي تحتاج إدخال
    if (m.quoted && m.quoted.text) {
        let quotedText = m.quoted.text;
        
        // إذاعة
        if (quotedText.includes('أمر الإذاعة') || quotedText.includes('📢 *أمر الإذاعة*')) {
            let groups = Object.values(await conn.groupFetchAllParticipating());
            let suc = 0, fail = 0;
            await m.react('📢');
            m.reply(`📢 *جاري البث إلى ${groups.length} مجموعة...*`);
            
            for (let g of groups) {
                try {
                    await conn.sendMessage(g.id, { 
                        text: `📢 *بث من المطور*\n\n${text}`,
                        contextInfo: { mentionedJid: [m.sender] }
                    });
                    suc++;
                    await new Promise(r => setTimeout(r, 1200));
                } catch { fail++; }
            }
            return m.reply(`✅ *تم البث*\n✓ نجح: ${suc}\n✗ فشل: ${fail}`);
        }
        
        // تغيير اسم البوت
        if (quotedText.includes('تغيير اسم البوت') || quotedText.includes('📛 *تغيير اسم البوت*')) {
            global.db.data.settings.botName = text;
            await m.react('✅');
            return m.reply(`✅ *تم تغيير اسم البوت إلى*\n> ${text}`);
        }
        
        // تغيير صورة البوت
        if (quotedText.includes('تغيير صورة البوت') && m.quoted.mimetype?.includes('image')) {
            let img = await m.download();
            await conn.updateProfilePicture(conn.user.jid, img);
            await m.react('✅');
            return m.reply('✅ *تم تغيير صورة البوت*');
        }
        
        // إضافة مطور
        if (quotedText.includes('إضافة مطور جديد')) {
            let target = m.mentionedJid[0] || text.match(/[0-9]+/g)?.[0] + '@s.whatsapp.net';
            if (!target) return m.reply('❌ يرجى منشن الشخص');
            if (!global.db.data.settings.owners) global.db.data.settings.owners = [];
            if (global.db.data.settings.owners.includes(target)) {
                return m.reply('⚠️ هذا الشخص مطور بالفعل');
            }
            global.db.data.settings.owners.push(target);
            await m.react('➕');
            return m.reply(`✅ *تمت إضافة @${target.split('@')[0]} كمطور*`, null, { mentions: [target] });
        }
        
        // حذف مطور
        if (quotedText.includes('حذف مطور')) {
            let target = m.mentionedJid[0];
            if (!target) return m.reply('❌ يرجى منشن المطور');
            let owners = global.db.data.settings.owners || [];
            let index = owners.indexOf(target);
            if (index === -1) return m.reply('⚠️ هذا الشخص ليس مطور');
            owners.splice(index, 1);
            await m.react('➖');
            return m.reply(`✅ *تم حذف @${target.split('@')[0]} من المطورين*`, null, { mentions: [target] });
        }
        
        // تعيين مالك
        if (quotedText.includes('تعيين مالك جديد')) {
            let num = text.replace(/\D/g, '');
            if (!num) return m.reply('❌ أرسل الرقم');
            let jid = num + '@s.whatsapp.net';
            global.db.data.settings.ownerJid = jid;
            await m.react('👑');
            return m.reply(`👑 *تم تعيين المالك الجديد*\n> ${num}`);
        }
        
        // رفع مشرف
        if (quotedText.includes('رفع مشرف')) {
            let target = m.mentionedJid[0];
            if (!target) return m.reply('❌ يرجى منشن الشخص');
            await conn.groupParticipantsUpdate(m.chat, [target], 'promote');
            await m.react('👑');
            return m.reply(`👑 تم رفع @${target.split('@')[0]} مشرف`, null, { mentions: [target] });
        }
        
        // تنزيل مشرف
        if (quotedText.includes('تنزيل مشرف')) {
            let target = m.mentionedJid[0];
            if (!target) return m.reply('❌ يرجى منشن المشرف');
            await conn.groupParticipantsUpdate(m.chat, [target], 'demote');
            await m.react('⬇️');
            return m.reply(`⬇️ تم تنزيل @${target.split('@')[0]} من المشرفين`, null, { mentions: [target] });
        }
        
        // طرد عضو
        if (quotedText.includes('طرد عضو')) {
            let target = m.mentionedJid[0];
            if (!target) return m.react('❌ يرجى منشن العضو');
            await conn.groupParticipantsUpdate(m.chat, [target], 'remove');
            await m.react('👢');
            return m.reply(`👢 تم طرد @${target.split('@')[0]}`, null, { mentions: [target] });
        }
        
        // حظر مستخدم
        if (quotedText.includes('حظر مستخدم')) {
            let target = m.mentionedJid[0];
            if (!target) return m.reply('❌ يرجى منشن الشخص');
            await conn.updateBlockStatus(target, 'block');
            await m.react('🚫');
            return m.reply(`🚫 تم حظر @${target.split('@')[0]}`, null, { mentions: [target] });
        }
        
        // فك حظر
        if (quotedText.includes('فك حظر')) {
            let target = m.mentionedJid[0];
            if (!target) return m.reply('❌ يرجى منشن الشخص');
            await conn.updateBlockStatus(target, 'unblock');
            await m.react('✅');
            return m.reply(`✅ تم فك الحظر عن @${target.split('@')[0]}`, null, { mentions: [target] });
        }
    }
    
    // ======================= الأوامر المباشرة =======================
    
    // إعادة تشغيل
    if (command === "ريستارت") {
        await m.react('🔄');
        await m.reply('🔄 *جاري إعادة تشغيل البوت...*\n> سأعود خلال ثواني');
        setTimeout(() => process.exit(1), 2000);
    }
    
    // إيقاف البوت
    if (command === "اطفاء") {
        await m.react('💀');
        await m.reply('💀 *تم إيقاف البوت*\n> استخدم npm start للتشغيل');
        setTimeout(() => process.exit(0), 2000);
    }
    
    // تحديث البوت
    if (command === "تحديث") {
        await m.react('🔄');
        try {
            let { stdout, stderr } = await execAsync('git pull');
            let msg = stdout || stderr || '✅ تم التحديث';
            m.reply(`🔄 *تحديث*\n\n${msg}`);
        } catch (e) {
            m.reply(`❌ خطأ: ${e.message}`);
        }
    }
    
    // قائمة المطورين
    if (command === "قائمة-المطورين") {
        let owners = global.db.data.settings.owners || [MAIN_OWNER];
        let txt = '👑 *قائمة المطورين*\n\n';
        owners.forEach(o => txt += `• @${o.split('@')[0]}\n`);
        await m.react('👑');
        m.reply(txt, null, { mentions: owners });
    }
    
    // تشغيل البوت
    if (command === "تشغيل-البوت") {
        global.db.data.settings.groupControl.botEnabled = true;
        await m.react('✅');
        m.reply('✅ *تم تشغيل البوت في جميع المجموعات*');
    }
    
    // إطفاء البوت
    if (command === "اطفاء-البوت") {
        global.db.data.settings.groupControl.botEnabled = false;
        await m.react('❌');
        m.reply('❌ *تم إطفاء البوت في جميع المجموعات*');
    }
    
    // تفعيل حماية الروابط
    if (command === "تفعيل-حماية") {
        global.db.data.settings.groupControl.antilink = true;
        await m.react('🔗');
        m.reply('✅ *تم تفعيل حماية الروابط*');
    }
    
    // تعطيل حماية الروابط
    if (command === "تعطيل-حماية") {
        global.db.data.settings.groupControl.antilink = false;
        await m.react('🔓');
        m.reply('❌ *تم تعطيل حماية الروابط*');
    }
    
    // حالة المجموعات
    if (command === "حالة-المجموعات") {
        let s = global.db.data.settings.groupControl;
        let status = s.botEnabled ? '✅ مفعل' : '❌ معطل';
        let txt = `📊 *حالة التحكم بالمجموعات*\n\n`;
        txt += `البوت في المجموعات: ${status}\n`;
        txt += `عدد المستثناة: ${s.allowedGroups.length}\n`;
        txt += `عدد المحظورة: ${s.bannedGroups.length}\n`;
        txt += `حماية الروابط: ${s.antilink ? '✅' : '❌'}\n`;
        txt += `المجموعات المكتومة: ${s.muteGroups.length}`;
        await m.react('📊');
        m.reply(txt);
    }
    
    // إغلاق المجموعة
    if (command === "اغلاق-المجموعة") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        await conn.groupSettingUpdate(m.chat, 'announcement');
        await m.react('🔒');
        m.reply('🔒 *تم إغلاق المجموعة*');
    }
    
    // فتح المجموعة
    if (command === "فتح-المجموعة") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        await conn.groupSettingUpdate(m.chat, 'not_announcement');
        await m.react('🔓');
        m.reply('🔓 *تم فتح المجموعة*');
    }
    
    // رابط المجموعة
    if (command === "رابط-المجموعة") {
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        let link = await conn.groupInviteCode(m.chat);
        let url = 'https://chat.whatsapp.com/' + link;
        await m.react('🔗');
        m.reply(`🔗 *رابط المجموعة*\n${url}`);
    }
    
    // كتم المجموعة
    if (command === "كتم-مجموعة") {
        let gc = m.chat;
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        let muted = global.db.data.settings.groupControl.muteGroups;
        if (!muted.includes(gc)) {
            muted.push(gc);
            await m.react('🔇');
            m.reply('🔇 *تم كتم هذه المجموعة*');
        } else {
            m.reply('⚠️ هذه المجموعة مكتومة بالفعل');
        }
    }
    
    // فك كتم
    if (command === "فك-كتم") {
        let gc = m.chat;
        if (!m.isGroup) return m.reply('❌ هذا الأمر في مجموعة فقط');
        let muted = global.db.data.settings.groupControl.muteGroups;
        let index = muted.indexOf(gc);
        if (index !== -1) {
            muted.splice(index, 1);
            await m.react('🔊');
            m.reply('🔊 *تم فك الكتم عن هذه المجموعة*');
        } else {
            m.reply('⚠️ هذه المجموعة ليست مكتومة');
        }
    }
    
    // المجموعات المكتومة
    if (command === "المكتومة") {
        let muted = global.db.data.settings.groupControl.muteGroups;
        if (muted.length === 0) return m.reply('📭 لا توجد مجموعات مكتومة');
        let txt = '🔇 *المجموعات المكتومة*\n\n';
        for (let i = 0; i < muted.length; i++) {
            try {
                let meta = await conn.groupMetadata(muted[i]);
                txt += `${i+1}. ${meta.subject}\n`;
            } catch {
                txt += `${i+1}. ${muted[i]}\n`;
            }
        }
        await m.react('📋');
        m.reply(txt);
    }
    
    // المحظورين
    if (command === "المحظورين") {
        let blocks = await conn.fetchBlocklist();
        if (!blocks || blocks.length === 0) return m.reply('📭 لا توجد أرقام محظورة');
        let txt = '🚫 *قائمة المحظورين*\n\n';
        blocks.forEach((b, i) => txt += `${i+1}. @${b.split('@')[0]}\n`);
        await m.react('📋');
        m.reply(txt, null, { mentions: blocks });
    }
    
    // إحصائيات
    if (command === "احصائيات") {
        let uptime = process.uptime();
        let h = Math.floor(uptime / 3600);
        let min = Math.floor((uptime % 3600) / 60);
        let s = Math.floor(uptime % 60);
        let memory = process.memoryUsage();
        let groups = Object.values(await conn.groupFetchAllParticipating()).length;
        
        let txt = `📊 *إحصائيات البوت*\n\n`;
        txt += `🕐 *وقت التشغيل:* ${h}h ${min}m ${s}s\n`;
        txt += `💾 *الذاكرة:* ${(memory.heapUsed / 1024 / 1024).toFixed(2)} MB\n`;
        txt += `👥 *المجموعات:* ${groups}\n`;
        txt += `👑 *المطور:* ${OWNER_NAME}\n`;
        await m.react('📊');
        m.reply(txt);
    }
}

handler.help = ["اعدادات-المطور"];
handler.tags = ["owner"];
handler.command = /^(اعدادات-المطور|اوامر-المطور|قايمة-البوت|قايمة-المطورين|قايمة-المجموعات|قايمة-الادارة|قايمة-الحظر|اذاعة|تغيير-اسم|تغيير-صورة|ريستارت|اطفاء|تحديث|اضافة-مطور|حذف-مطور|تعيين-مالك|قائمة-المطورين|تشغيل-البوت|اطفاء-البوت|تفعيل-حماية|تعطيل-حماية|حالة-المجموعات|اغلاق-المجموعة|فتح-المجموعة|رابط-المجموعة|رفع-مشرف|تنزيل-مشرف|طرد-عضو|حظر-مستخدم|فك-حظر|كتم-مجموعة|فك-كتم|المكتومة|المحظورين|احصائيات)$/i;

export default handler;